# KronosPlayer v0.2

Native C++17 workstation-style instrument for Intel macOS.

**No JUCE. No Electron. No browser UI.**

Target:
- iMac 2011
- Intel x86_64
- macOS 10.13+
- CoreAudio
- CoreMIDI
- Cocoa UI
- CMake/Xcode

## Working now

- 16-layer Performance engine
- Per-layer enable/mute
- Per-layer engine selection
- Per-layer volume and pan
- MIDI channel routing
- Key low/high
- Velocity low/high
- Transpose
- Fine tune
- CC11 expression per layer
- Save/load `.kperf`
- CoreAudio real-time output
- CoreMIDI keyboard input
- Native Cocoa Performance editor
- No allocation in the steady-state audio render path

Three real C++ sound engines are included:

- `AL-1 Core` — dual oscillator subtractive engine
- `PolysixEX Core` — single oscillator + sub + resonant LPF subtractive engine
- `CX-3 Core` — 9-drawbar additive organ engine

These are original clean-room C++ implementations for this project. They are **not claimed to be bit-exact Korg algorithms**.

## Build on iMac 2011

```bash
mkdir build
cd build
cmake -G Xcode \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.13 \
  ..
cmake --build . --config Release
```

Then run the built `KronosPlayer.app`.

## Performance format

The app saves performances as text `.kperf` files.

Each performance contains 16 layers. Every layer stores:

- engine
- MIDI channel
- key range
- velocity range
- transpose
- fine tune
- volume
- pan
- expression

## PCG

`PcgReader` currently performs safe KORG-header validation and bounded chunk scanning.

Exact KRONOS Program/Combi parameter mapping is intentionally not marked complete yet.
