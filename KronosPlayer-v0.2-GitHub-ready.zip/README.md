# KronosPlayer v0.3

Native C++17 workstation-style instrument for Intel macOS.

**No JUCE. No Electron. No browser UI.**

Target:
- iMac 2011
- Intel x86_64
- macOS 10.13+
- CoreAudio
- CoreMIDI
- Cocoa UI
- CMake/Xcode

## v0.3: actual engine editing

The app now has two working areas:

1. **16-layer Performance** — engine selection, enable, MIDI channel, key range, transpose, volume, pan and CC11 expression.
2. **ENGINE EDIT** — controls are connected to DSP parameters, not decorative GUI objects.

### AL-1 Core editor
- Oscillator 1 waveform
- Oscillator 1 level
- Oscillator 1 tune
- Oscillator 1 detune
- Oscillator 2 waveform
- Oscillator 2 level
- Oscillator 2 tune
- Oscillator 2 detune
- Filter cutoff
- Filter resonance
- Amp attack / decay / sustain / release
- Output gain

### PolysixEX Core editor
- oscillator waveform
- oscillator level
- sub level
- filter cutoff / resonance
- amp ADSR
- output gain

### CX-3 Core editor
- all 9 drawbars
- output gain

Parameter changes are fed into the actual C++ DSP engines and affect generated audio. Engine parameters are also stored in `.kperf` performances and restored on load.

These are original clean-room engine implementations for this project. They are **not claimed to be bit-exact Korg KRONOS algorithms yet**.

## Build on iMac 2011

```bash
mkdir build
cd build
cmake -G Xcode \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.13 \
  ..
cmake --build . --config Release
```

## MIDI / audio path

```text
USB/MIDI keyboard
        ↓
     CoreMIDI
        ↓
16-layer Performance Engine
        ↓
AL-1 / PolysixEX / CX-3 DSP
        ↓
      Mixer
        ↓
     CoreAudio
```

## PCG

The current PCG reader validates KORG headers and bounded chunks. Exact KRONOS Program/Combi parameter mapping is still under development and is not marked complete.

## Built-in test keyboard

The macOS app now includes a real 37-key on-screen piano keyboard (C3-C6).

- Mouse down sends real MIDI Note On into `PerformanceEngine`
- Mouse up sends real MIDI Note Off
- Dragging across keys retriggers notes
- Velocity is adjustable from 1 to 127
- `Release Keys` performs an all-notes-off safety release
- The keyboard plays the currently enabled Performance layers, so it tests the actual DSP path, not a UI mock



## Expanded AL-1 engine

The AL-1 Core editor now exposes real DSP controls for:

- OSC1 / OSC2 waveform, level, tuning and detune
- hard oscillator sync
- ring modulation
- sub oscillator
- noise source
- 1–3 voice unison per oscillator with detune spread
- portamento
- pitch envelope
- two independent multimode filters (LP / HP / BP)
- serial or parallel dual-filter routing
- filter key tracking
- filter envelope
- velocity-to-filter modulation
- channel-aftertouch-to-filter modulation
- amp envelope
- LFO waveform/rate
- LFO-to-pitch / filter / amp
- mod-wheel scaling of the LFO path
- drive / waveshaping
- output gain

The controls are connected to the C++ DSP and saved inside `.kperf`.

This remains an original clean-room implementation and is not claimed to be
a bit-exact copy of Korg's proprietary AL-1 algorithm.
