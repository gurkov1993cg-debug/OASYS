#include "performance/PerformanceEngine.h"
#include "performance/PerformanceIO.h"
#include <cmath>
#include <cstdio>
#include <iostream>
#include <vector>

static bool finiteAndNonSilent(const std::vector<float>& b) {
    double energy = 0.0;

    for (float s : b) {
        if (!std::isfinite(s))
            return false;

        energy += static_cast<double>(s) * static_cast<double>(s);
    }

    return energy > 1e-10;
}

int main() {
    constexpr double sr = 48000.0;

    kp::PerformanceEngine engine;
    engine.setSampleRate(sr);

    kp::Performance p = kp::makeDefaultPerformance();
    p.name = "Unit Test Blend";

    p.layers[0].enabled = true;
    p.layers[0].engine = kp::EngineType::Al1;

    p.layers[1].enabled = true;
    p.layers[1].engine = kp::EngineType::Polysix;

    p.layers[2].enabled = true;
    p.layers[2].engine = kp::EngineType::Cx3;

    p.layers[3].enabled = false;

    engine.setPerformance(p);

    kp::MidiEvent on;
    on.type = kp::MidiType::NoteOn;
    on.channel = 0;
    on.data1 = 60;
    on.data2 = 120;

    engine.handleMidi(on);

    std::vector<float> audio(4096 * 2, 0.0f);
    engine.render(audio.data(), 4096);

    if (!finiteAndNonSilent(audio)) {
        std::cerr << "FAIL: layered render is silent or invalid\n";
        return 1;
    }

    const std::string path = "roundtrip-test.kperf";
    std::string error;

    if (!kp::savePerformance(engine.performance(), path, &error)) {
        std::cerr << "FAIL save: " << error << "\n";
        return 2;
    }

    kp::Performance loaded;

    if (!kp::loadPerformance(path, loaded, &error)) {
        std::cerr << "FAIL load: " << error << "\n";
        return 3;
    }

    std::remove(path.c_str());

    if (loaded.name != "Unit Test Blend") {
        std::cerr << "FAIL: name roundtrip\n";
        return 4;
    }

    if (loaded.layers[1].engine != kp::EngineType::Polysix ||
        loaded.layers[2].engine != kp::EngineType::Cx3) {
        std::cerr << "FAIL: engine roundtrip\n";
        return 5;
    }

    // Key-range test: only layer 0 active and note outside its range -> silence.
    kp::Performance rangeTest{};
    rangeTest.name = "Range Test";
    rangeTest.layers[0].enabled = true;
    rangeTest.layers[0].engine = kp::EngineType::Al1;
    rangeTest.layers[0].keyLow = 80;
    rangeTest.layers[0].keyHigh = 100;

    engine.setPerformance(rangeTest);

    engine.handleMidi(on);

    std::vector<float> silence(1024 * 2, 0.0f);
    engine.render(silence.data(), 1024);

    double energy = 0.0;
    for (float s : silence)
        energy += static_cast<double>(s) * static_cast<double>(s);

    if (energy > 1e-12) {
        std::cerr << "FAIL: key-range routing\n";
        return 6;
    }

    std::cout
        << "PASS: 16-layer performance, 3 engines, routing and KPERF roundtrip\n";

    return 0;
}
