#include "performance/PerformanceEngine.h"
#include "performance/PerformanceIO.h"
#include "engine/Al1Engine.h"
#include "engine/Cx3Engine.h"
#include <cmath>
#include <cstdio>
#include <iostream>
#include <vector>

static double energyOf(const std::vector<float>& b) {
    double energy = 0.0;
    for (float s : b) {
        if (!std::isfinite(s))
            return -1.0;
        energy += static_cast<double>(s) * static_cast<double>(s);
    }
    return energy;
}

static double meanAbsDiff(const std::vector<float>& a,
                          const std::vector<float>& b) {
    if (a.size() != b.size() || a.empty())
        return 1e9;

    double sum = 0.0;
    for (std::size_t i = 0; i < a.size(); ++i)
        sum += std::abs((double)a[i] - (double)b[i]);

    return sum / (double)a.size();
}

static std::vector<float> renderNote(kp::PerformanceEngine& engine,
                                     std::uint8_t note,
                                     std::uint8_t velocity,
                                     std::size_t frames) {
    engine.allNotesOff();

    kp::MidiEvent on;
    on.type = kp::MidiType::NoteOn;
    on.channel = 0;
    on.data1 = note;
    on.data2 = velocity;
    engine.handleMidi(on);

    std::vector<float> audio(frames * 2, 0.0f);
    engine.render(audio.data(), frames);
    return audio;
}

int main() {
    constexpr double sr = 48000.0;

    kp::PerformanceEngine engine;
    engine.setSampleRate(sr);

    kp::Performance p = kp::makeDefaultPerformance();
    p.name = "Unit Test Blend";
    engine.setPerformance(p);

    auto layered = renderNote(engine, 60, 120, 4096);
    if (energyOf(layered) <= 1e-10) {
        std::cerr << "FAIL: layered render is silent or invalid\n";
        return 1;
    }

    kp::Performance al1Only{};
    al1Only.name = "AL1 expanded test";
    kp::resetLayerEngineParameters(al1Only.layers[0], kp::EngineType::Al1);
    al1Only.layers[0].enabled = true;
    al1Only.layers[0].volume = 1.0f;
    engine.setPerformance(al1Only);

    // Baseline deterministic render.
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Osc1Level, 0.8f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Osc2Level, 0.35f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::NoiseLevel, 0.0f);
    auto baseline = renderNote(engine, 60, 120, 4096);

    if (energyOf(baseline) <= 1e-10) {
        std::cerr << "FAIL: AL-1 baseline silent\n";
        return 2;
    }

    // Oscillator interaction must actually change DSP.
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::HardSync, 1.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::RingMod, 0.75f);
    auto syncedRing = renderNote(engine, 60, 120, 4096);

    if (meanAbsDiff(baseline, syncedRing) < 1e-4) {
        std::cerr << "FAIL: hard-sync/ring-mod controls do not change audio\n";
        return 3;
    }

    // Dual-filter routing must change audio.
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::HardSync, 0.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::RingMod, 0.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Filter1Mode, 0.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Filter2Mode, 1.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Filter1Cutoff, 1800.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Filter2Cutoff, 3200.0f);

    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::FilterRouting, 0.0f);
    auto serial = renderNote(engine, 64, 110, 4096);

    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::FilterRouting, 1.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::ParallelBalance, 0.5f);
    auto parallel = renderNote(engine, 64, 110, 4096);

    if (meanAbsDiff(serial, parallel) < 1e-4) {
        std::cerr << "FAIL: serial/parallel dual-filter routing has no effect\n";
        return 4;
    }

    // LFO / unison / drive parameters are live and readable.
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::UnisonVoices, 3.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::UnisonSpreadCents, 18.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::LfoRateHz, 6.5f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::LfoPitchSemis, 0.35f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Drive, 4.0f);

    if (std::lround(engine.getEngineParameter(
            0,
            (std::uint32_t)kp::Al1Parameter::UnisonVoices)) != 3 ||
        std::abs(engine.getEngineParameter(
            0,
            (std::uint32_t)kp::Al1Parameter::Drive) - 4.0f) > 0.001f) {
        std::cerr << "FAIL: expanded AL-1 parameter readback\n";
        return 5;
    }

    auto modulated = renderNote(engine, 67, 115, 4096);
    if (energyOf(modulated) <= 1e-10) {
        std::cerr << "FAIL: expanded AL-1 render silent\n";
        return 6;
    }

    // Aftertouch route should be accepted without destabilizing audio.
    engine.setEngineParameter(
        0,
        (std::uint32_t)kp::Al1Parameter::AftertouchToFilterOctaves,
        2.0f);

    kp::MidiEvent pressure;
    pressure.type = kp::MidiType::ChannelPressure;
    pressure.channel = 0;
    pressure.data1 = 100;
    engine.handleMidi(pressure);

    auto aftertouchAudio = renderNote(engine, 67, 115, 2048);
    if (energyOf(aftertouchAudio) <= 1e-10) {
        std::cerr << "FAIL: aftertouch path broke AL-1 audio\n";
        return 7;
    }

    // KPERF must persist the expanded AL-1 engine state (> old 16-param limit).
    const std::string path = "roundtrip-test.kperf";
    std::string error;
    engine.performance().name = "Saved Expanded AL1";

    if (!kp::savePerformance(engine.performance(), path, &error)) {
        std::cerr << "FAIL save: " << error << "\n";
        return 8;
    }

    kp::Performance loaded;
    if (!kp::loadPerformance(path, loaded, &error)) {
        std::cerr << "FAIL load: " << error << "\n";
        return 9;
    }

    std::remove(path.c_str());

    const auto driveIndex = (std::size_t)kp::Al1Parameter::Drive;
    const auto routingIndex = (std::size_t)kp::Al1Parameter::FilterRouting;

    if (loaded.name != "Saved Expanded AL1" ||
        loaded.layers[0].engineParameterCount <= 16 ||
        std::abs(loaded.layers[0].engineParameters[driveIndex] - 4.0f) > 0.001f ||
        std::lround(loaded.layers[0].engineParameters[routingIndex]) != 1) {
        std::cerr << "FAIL: expanded AL-1 KPERF roundtrip\n";
        return 10;
    }

    // Existing CX-3 path remains alive.
    kp::Performance cx{};
    kp::resetLayerEngineParameters(cx.layers[0], kp::EngineType::Cx3);
    cx.layers[0].enabled = true;
    engine.setPerformance(cx);

    engine.setEngineParameter(
        0,
        (std::uint32_t)kp::Cx3Parameter::Drawbar1,
        0.0f);

    if (std::abs(engine.getEngineParameter(
            0,
            (std::uint32_t)kp::Cx3Parameter::Drawbar1)) > 0.0001f) {
        std::cerr << "FAIL: CX-3 drawbar control\n";
        return 11;
    }

    // Key-range routing still works.
    kp::Performance rangeTest{};
    kp::resetLayerEngineParameters(
        rangeTest.layers[0],
        kp::EngineType::Al1);

    rangeTest.layers[0].enabled = true;
    rangeTest.layers[0].keyLow = 80;
    rangeTest.layers[0].keyHigh = 100;

    engine.setPerformance(rangeTest);

    auto silence = renderNote(engine, 60, 120, 1024);

    if (energyOf(silence) > 1e-12) {
        std::cerr << "FAIL: key-range routing\n";
        return 12;
    }

    std::cout
        << "PASS: expanded AL-1 oscillator interaction, unison, glide, "
           "pitch/filter EG, dual filters, LFO/AMS, aftertouch, drive, "
           "16-layer routing and KPERF persistence\n";

    return 0;
}
