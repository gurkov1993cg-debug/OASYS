#include "performance/PerformanceEngine.h"
#include "performance/PerformanceIO.h"
#include "engine/Al1Engine.h"
#include "engine/Cx3Engine.h"
#include <cmath>
#include <cstdio>
#include <iostream>
#include <vector>

static double energyOf(const std::vector<float>& b) {
    double energy = 0.0;
    for (float s : b) {
        if (!std::isfinite(s))
            return -1.0;
        energy += static_cast<double>(s) * static_cast<double>(s);
    }
    return energy;
}

static std::vector<float> renderNote(kp::PerformanceEngine& engine,
                                     std::uint8_t note,
                                     std::uint8_t velocity,
                                     std::size_t frames) {
    engine.allNotesOff();

    kp::MidiEvent on;
    on.type = kp::MidiType::NoteOn;
    on.channel = 0;
    on.data1 = note;
    on.data2 = velocity;
    engine.handleMidi(on);

    std::vector<float> audio(frames * 2, 0.0f);
    engine.render(audio.data(), frames);
    return audio;
}

int main() {
    constexpr double sr = 48000.0;

    kp::PerformanceEngine engine;
    engine.setSampleRate(sr);

    kp::Performance p = kp::makeDefaultPerformance();
    p.name = "Unit Test Blend";
    engine.setPerformance(p);

    auto layered = renderNote(engine, 60, 120, 4096);
    if (energyOf(layered) <= 1e-10) {
        std::cerr << "FAIL: layered render is silent or invalid\n";
        return 1;
    }

    // Real engine control: changing AL-1 oscillator level must alter audio energy.
    kp::Performance al1Only{};
    al1Only.name = "AL1 parameter test";
    kp::resetLayerEngineParameters(al1Only.layers[0], kp::EngineType::Al1);
    al1Only.layers[0].enabled = true;
    al1Only.layers[0].volume = 1.0f;
    engine.setPerformance(al1Only);

    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Osc1Level, 1.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Osc2Level, 0.0f);
    auto loud = renderNote(engine, 60, 120, 4096);
    const double loudEnergy = energyOf(loud);

    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Osc1Level, 0.05f);
    auto quiet = renderNote(engine, 60, 120, 4096);
    const double quietEnergy = energyOf(quiet);

    if (!(loudEnergy > quietEnergy * 3.0)) {
        std::cerr << "FAIL: AL-1 oscillator control does not affect DSP enough\n";
        return 2;
    }

    // Change waveform and tune; readback must reflect the DSP parameter layer.
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Osc1Wave, 3.0f);
    engine.setEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Osc1Semitone, 12.0f);
    if (std::lround(engine.getEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Osc1Wave)) != 3 ||
        std::lround(engine.getEngineParameter(0, (std::uint32_t)kp::Al1Parameter::Osc1Semitone)) != 12) {
        std::cerr << "FAIL: AL-1 parameter readback\n";
        return 3;
    }

    // KPERF must now persist engine parameters too.
    const std::string path = "roundtrip-test.kperf";
    std::string error;
    engine.performance().name = "Saved Synth Patch";

    if (!kp::savePerformance(engine.performance(), path, &error)) {
        std::cerr << "FAIL save: " << error << "\n";
        return 4;
    }

    kp::Performance loaded;
    if (!kp::loadPerformance(path, loaded, &error)) {
        std::cerr << "FAIL load: " << error << "\n";
        return 5;
    }
    std::remove(path.c_str());

    if (loaded.name != "Saved Synth Patch" ||
        std::lround(loaded.layers[0].engineParameters[(std::size_t)kp::Al1Parameter::Osc1Wave]) != 3 ||
        std::lround(loaded.layers[0].engineParameters[(std::size_t)kp::Al1Parameter::Osc1Semitone]) != 12) {
        std::cerr << "FAIL: engine parameter KPERF roundtrip\n";
        return 6;
    }

    // CX-3 drawbar is also a real engine parameter.
    kp::Performance cx{};
    kp::resetLayerEngineParameters(cx.layers[0], kp::EngineType::Cx3);
    cx.layers[0].enabled = true;
    engine.setPerformance(cx);
    engine.setEngineParameter(0, (std::uint32_t)kp::Cx3Parameter::Drawbar1, 0.0f);
    if (std::abs(engine.getEngineParameter(0, (std::uint32_t)kp::Cx3Parameter::Drawbar1)) > 0.0001f) {
        std::cerr << "FAIL: CX-3 drawbar control\n";
        return 7;
    }

    // Key-range routing still works.
    kp::Performance rangeTest{};
    kp::resetLayerEngineParameters(rangeTest.layers[0], kp::EngineType::Al1);
    rangeTest.layers[0].enabled = true;
    rangeTest.layers[0].keyLow = 80;
    rangeTest.layers[0].keyHigh = 100;
    engine.setPerformance(rangeTest);

    auto silence = renderNote(engine, 60, 120, 1024);
    if (energyOf(silence) > 1e-12) {
        std::cerr << "FAIL: key-range routing\n";
        return 8;
    }

    std::cout << "PASS: real engine parameters, 16-layer routing and KPERF engine-state roundtrip\n";
    return 0;
}
