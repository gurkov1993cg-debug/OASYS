#pragma once
#include "dsp/Oscillator.h"
#include "dsp/Adsr.h"
#include "dsp/SvfFilter.h"
#include "engine/Al1Patch.h"
#include <cstdint>

namespace kp {

class Voice {
public:
    void setSampleRate(double sampleRate) noexcept;

    void start(std::uint8_t note,
               std::uint8_t velocity,
               const Al1Patch& patch,
               std::uint64_t age,
               float pitchBendSemis) noexcept;

    void release(std::uint8_t note) noexcept;
    void forceStop() noexcept;

    void applyPatch(const Al1Patch& patch, float pitchBendSemis) noexcept;
    float process(const Al1Patch& patch) noexcept;

    bool active() const noexcept { return env_.isActive(); }
    std::uint8_t note() const noexcept { return note_; }
    std::uint64_t age() const noexcept { return age_; }

private:
    static double midiToHz(double note, float cents) noexcept;

    double sampleRate_{48000.0};
    std::uint8_t note_{0};
    float velocityGain_{0.0f};
    std::uint64_t age_{0};

    Oscillator osc1_;
    Oscillator osc2_;
    Adsr env_;
    SvfFilter filter_;
};

} // namespace kp
