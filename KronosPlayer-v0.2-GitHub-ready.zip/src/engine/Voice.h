#pragma once
#include "dsp/Oscillator.h"
#include "dsp/Adsr.h"
#include "dsp/SvfFilter.h"
#include "engine/Al1Patch.h"
#include <array>
#include <cstdint>

namespace kp {

class Voice {
public:
    static constexpr int kMaxUnison = 3;

    void setSampleRate(double sampleRate) noexcept;

    void start(std::uint8_t note,
               std::uint8_t velocity,
               const Al1Patch& patch,
               std::uint64_t age,
               float pitchBendSemis,
               float glideStartNote) noexcept;

    void release(std::uint8_t note) noexcept;
    void forceStop() noexcept;

    void applyPatch(const Al1Patch& patch) noexcept;

    float process(const Al1Patch& patch,
                  float pitchBendSemis,
                  float modWheel,
                  float aftertouch) noexcept;

    bool active() const noexcept { return ampEnv_.isActive(); }
    std::uint8_t note() const noexcept { return note_; }
    std::uint64_t age() const noexcept { return age_; }

private:
    static double midiToHz(double note, float cents) noexcept;
    static float clampCutoff(float hz, double sampleRate) noexcept;
    static float lfoValue(Waveform wave, double phase) noexcept;

    float processFilter(SvfFilter& filter,
                        float input,
                        FilterMode mode) noexcept;

    std::uint32_t nextNoise() noexcept;

    double sampleRate_{48000.0};
    std::uint8_t note_{0};
    float velocity_{0.0f};
    float velocityGain_{0.0f};
    std::uint64_t age_{0};

    float currentMidiNote_{60.0f};

    std::array<Oscillator, kMaxUnison> osc1_{};
    std::array<Oscillator, kMaxUnison> osc2_{};
    Oscillator subOsc_{};

    Adsr ampEnv_{};
    Adsr filterEnv_{};
    Adsr pitchEnv_{};

    SvfFilter filter1_{};
    SvfFilter filter2_{};

    double lfoPhase_{0.0};
    std::uint32_t noiseState_{0x12345678u};
};

} // namespace kp
