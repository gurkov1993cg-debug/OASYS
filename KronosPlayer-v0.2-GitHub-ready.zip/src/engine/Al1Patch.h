#pragma once
#include "dsp/Oscillator.h"

namespace kp {

struct Al1Patch {
    Waveform osc1Wave{Waveform::Saw};
    Waveform osc2Wave{Waveform::Square};

    float osc1Level{0.62f};
    float osc2Level{0.38f};

    int osc1Semitone{0};
    int osc2Semitone{-12};

    float osc1DetuneCents{0.0f};
    float osc2DetuneCents{7.0f};

    float cutoffHz{7000.0f};
    float resonance{0.18f};

    float ampAttack{0.008f};
    float ampDecay{0.18f};
    float ampSustain{0.78f};
    float ampRelease{0.30f};

    float masterGain{0.20f};
};

} // namespace kp
