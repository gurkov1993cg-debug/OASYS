#pragma once
#include "dsp/Oscillator.h"
#include "dsp/SvfFilter.h"
#include <cstdint>

namespace kp {

enum class FilterRouting : std::uint8_t {
    Serial = 0,
    Parallel = 1
};

struct Al1Patch {
    // OSC 1 / OSC 2
    Waveform osc1Wave{Waveform::Saw};
    Waveform osc2Wave{Waveform::Square};
    float osc1Level{0.62f};
    float osc2Level{0.38f};
    int osc1Semitone{0};
    int osc2Semitone{-12};
    float osc1DetuneCents{0.0f};
    float osc2DetuneCents{7.0f};

    // Oscillator interaction and extra sources
    bool hardSync{false};
    float ringMod{0.0f};
    float subLevel{0.0f};
    float noiseLevel{0.0f};

    // Unison / glide
    int unisonVoices{1};        // 1..3 per oscillator in this implementation
    float unisonSpreadCents{0.0f};
    float portamentoSeconds{0.0f};

    // Pitch EG
    float pitchEgAmountSemis{0.0f};
    float pitchEgAttack{0.005f};
    float pitchEgDecay{0.20f};
    float pitchEgRelease{0.10f};

    // Filter 1
    FilterMode filter1Mode{FilterMode::LowPass};
    float filter1CutoffHz{7000.0f};
    float filter1Resonance{0.18f};

    // Filter 2
    FilterMode filter2Mode{FilterMode::LowPass};
    float filter2CutoffHz{12000.0f};
    float filter2Resonance{0.05f};

    FilterRouting filterRouting{FilterRouting::Serial};
    float parallelBalance{0.5f};

    // Shared filter modulation
    float filterKeyTrack{0.0f};         // octaves per octave of keyboard tracking
    float filterEgAmountOctaves{0.0f};  // bipolar
    float velocityToFilterOctaves{0.0f};
    float aftertouchToFilterOctaves{0.0f};

    float filterEgAttack{0.01f};
    float filterEgDecay{0.25f};
    float filterEgSustain{0.0f};
    float filterEgRelease{0.35f};

    // Amp EG
    float ampAttack{0.008f};
    float ampDecay{0.18f};
    float ampSustain{0.78f};
    float ampRelease{0.30f};

    // LFO
    Waveform lfoWave{Waveform::Sine};
    float lfoRateHz{5.2f};
    float lfoPitchSemis{0.0f};
    float lfoFilterOctaves{0.0f};
    float lfoAmpDepth{0.0f};
    float modWheelToLfo{1.0f};

    // Output non-linearity
    float drive{1.0f};
    float masterGain{0.20f};
};

} // namespace kp
