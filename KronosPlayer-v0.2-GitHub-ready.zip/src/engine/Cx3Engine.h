#pragma once
#include "engine/IEngine.h"
#include "dsp/Adsr.h"
#include <array>
#include <cstdint>

namespace kp {

enum class Cx3Parameter : std::uint32_t {
    Drawbar1 = 0,
    Drawbar2,
    Drawbar3,
    Drawbar4,
    Drawbar5,
    Drawbar6,
    Drawbar7,
    Drawbar8,
    Drawbar9,
    MasterGain
};

class Cx3Engine final : public IEngine {
public:
    EngineType type() const noexcept override { return EngineType::Cx3; }

    void setSampleRate(double sampleRate) noexcept override;
    void noteOn(std::uint8_t note, std::uint8_t velocity) noexcept override;
    void noteOff(std::uint8_t note) noexcept override;
    void controlChange(std::uint8_t cc, std::uint8_t value) noexcept override;
    void pitchBend(std::uint16_t value14) noexcept override;
    void render(float* out, std::size_t frames) noexcept override;
    void allNotesOff() noexcept override;
    void setParameter(std::uint32_t parameterId, float value) noexcept override;
    float getParameter(std::uint32_t parameterId) const noexcept override;

private:
    struct OVoice {
        std::uint8_t note{0};
        float velocity{0.0f};
        std::uint64_t age{0};
        bool active{false};
        std::array<double, 9> phase{};
        Adsr env;
    };

    static double noteHz(double note) noexcept;
    OVoice* allocate() noexcept;

    double sampleRate_{48000.0};
    std::array<OVoice, 32> voices_{};
    std::uint64_t age_{1};
    float bendSemis_{0.0f};
    float masterGain_{0.22f};

    std::array<float, 9> drawbars_{
        0.75f, 1.0f, 0.58f, 0.75f, 0.45f, 0.35f, 0.25f, 0.22f, 0.18f
    };
};

} // namespace kp
