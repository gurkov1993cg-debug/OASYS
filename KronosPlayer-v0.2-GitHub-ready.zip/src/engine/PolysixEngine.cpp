#include "engine/PolysixEngine.h"
#include <algorithm>
#include <cmath>

namespace kp {

double PolysixEngine::noteHz(double note) noexcept {
    return 440.0 * std::pow(2.0, (note - 69.0) / 12.0);
}

void PolysixEngine::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;

    for (auto& v : voices_) {
        v.osc.setSampleRate(sampleRate_);
        v.sub.setSampleRate(sampleRate_);
        v.env.setSampleRate(sampleRate_);
        v.filter.setSampleRate(sampleRate_);
    }
}

void PolysixEngine::tuneVoice(PVoice& v) noexcept {
    v.osc.setFrequency(noteHz(static_cast<double>(v.note) + bendSemis_));
    v.sub.setFrequency(noteHz(static_cast<double>(v.note - 12) + bendSemis_));
}

void PolysixEngine::applyVoiceParameters(PVoice& v) noexcept {
    v.osc.setWaveform(waveform_);
    v.sub.setWaveform(Waveform::Square);
    tuneVoice(v);
    v.filter.setCutoff(cutoff_);
    v.filter.setResonance(resonance_);
    v.env.setParameters(attack_, decay_, sustain_, release_);
}

PolysixEngine::PVoice* PolysixEngine::allocate() noexcept {
    for (auto& v : voices_) {
        if (!v.active)
            return &v;
    }

    PVoice* oldest = &voices_[0];
    for (auto& v : voices_) {
        if (v.age < oldest->age)
            oldest = &v;
    }
    return oldest;
}

void PolysixEngine::noteOn(std::uint8_t note, std::uint8_t velocity) noexcept {
    if (velocity == 0) {
        noteOff(note);
        return;
    }

    auto* v = allocate();
    v->note = note;
    v->velocity = static_cast<float>(velocity) / 127.0f;
    v->age = age_++;
    v->active = true;

    applyVoiceParameters(*v);
    v->osc.reset(0.0);
    v->sub.reset(0.25);
    v->filter.reset();
    v->env.reset();
    v->env.setParameters(attack_, decay_, sustain_, release_);
    v->env.noteOn();
}

void PolysixEngine::noteOff(std::uint8_t note) noexcept {
    for (auto& v : voices_) {
        if (v.active && v.note == note)
            v.env.noteOff();
    }
}

void PolysixEngine::controlChange(std::uint8_t cc, std::uint8_t value) noexcept {
    const float n = static_cast<float>(value) / 127.0f;

    if (cc == 74) {
        cutoff_ = 60.0f * std::pow(18000.0f / 60.0f, n);
    } else if (cc == 71) {
        resonance_ = std::clamp(n * 0.95f, 0.0f, 0.95f);
    }
}

void PolysixEngine::pitchBend(std::uint16_t value14) noexcept {
    bendSemis_ = ((static_cast<int>(value14) - 8192) / 8192.0f) * 2.0f;
}

void PolysixEngine::setParameter(std::uint32_t parameterId, float value) noexcept {
    switch (static_cast<PolysixParameter>(parameterId)) {
        case PolysixParameter::Wave:
            waveform_ = static_cast<Waveform>(std::clamp(static_cast<int>(std::lround(value)), 0, 3));
            break;
        case PolysixParameter::OscLevel: oscLevel_ = std::clamp(value, 0.0f, 1.0f); break;
        case PolysixParameter::SubLevel: subLevel_ = std::clamp(value, 0.0f, 1.0f); break;
        case PolysixParameter::FilterCutoff: cutoff_ = std::clamp(value, 20.0f, 18000.0f); break;
        case PolysixParameter::FilterResonance: resonance_ = std::clamp(value, 0.0f, 0.98f); break;
        case PolysixParameter::AmpAttack: attack_ = std::clamp(value, 0.001f, 10.0f); break;
        case PolysixParameter::AmpDecay: decay_ = std::clamp(value, 0.001f, 10.0f); break;
        case PolysixParameter::AmpSustain: sustain_ = std::clamp(value, 0.0f, 1.0f); break;
        case PolysixParameter::AmpRelease: release_ = std::clamp(value, 0.001f, 15.0f); break;
        case PolysixParameter::MasterGain: masterGain_ = std::clamp(value, 0.0f, 1.0f); break;
    }
}

float PolysixEngine::getParameter(std::uint32_t parameterId) const noexcept {
    switch (static_cast<PolysixParameter>(parameterId)) {
        case PolysixParameter::Wave: return static_cast<float>(waveform_);
        case PolysixParameter::OscLevel: return oscLevel_;
        case PolysixParameter::SubLevel: return subLevel_;
        case PolysixParameter::FilterCutoff: return cutoff_;
        case PolysixParameter::FilterResonance: return resonance_;
        case PolysixParameter::AmpAttack: return attack_;
        case PolysixParameter::AmpDecay: return decay_;
        case PolysixParameter::AmpSustain: return sustain_;
        case PolysixParameter::AmpRelease: return release_;
        case PolysixParameter::MasterGain: return masterGain_;
    }
    return 0.0f;
}

void PolysixEngine::render(float* out, std::size_t frames) noexcept {
    if (!out) return;

    for (auto& v : voices_) {
        if (v.active)
            applyVoiceParameters(v);
    }

    for (std::size_t i = 0; i < frames; ++i) {
        float s = 0.0f;

        for (auto& v : voices_) {
            if (!v.active) continue;

            const float src =
                v.osc.process() * oscLevel_ +
                v.sub.process() * subLevel_;

            const float e = v.env.process();
            s += v.filter.processLowPass(src)
               * e
               * v.velocity
               * masterGain_;

            if (!v.env.isActive())
                v.active = false;
        }

        s = std::tanh(s);
        out[i*2] = s;
        out[i*2 + 1] = s;
    }
}

void PolysixEngine::allNotesOff() noexcept {
    for (auto& v : voices_) {
        v.env.reset();
        v.active = false;
    }
}

} // namespace kp
