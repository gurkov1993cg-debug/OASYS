#include "engine/PolysixEngine.h"
#include <algorithm>
#include <cmath>

namespace kp {

double PolysixEngine::noteHz(double note) noexcept {
    return 440.0 * std::pow(2.0, (note - 69.0) / 12.0);
}

void PolysixEngine::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;

    for (auto& v : voices_) {
        v.osc.setSampleRate(sampleRate_);
        v.sub.setSampleRate(sampleRate_);
        v.env.setSampleRate(sampleRate_);
        v.filter.setSampleRate(sampleRate_);
    }
}

void PolysixEngine::tuneVoice(PVoice& v) noexcept {
    v.osc.setFrequency(noteHz(static_cast<double>(v.note) + bendSemis_));
    v.sub.setFrequency(noteHz(static_cast<double>(v.note - 12) + bendSemis_));
}

PolysixEngine::PVoice* PolysixEngine::allocate() noexcept {
    for (auto& v : voices_) {
        if (!v.active)
            return &v;
    }

    PVoice* oldest = &voices_[0];
    for (auto& v : voices_) {
        if (v.age < oldest->age)
            oldest = &v;
    }
    return oldest;
}

void PolysixEngine::noteOn(std::uint8_t note, std::uint8_t velocity) noexcept {
    if (velocity == 0) {
        noteOff(note);
        return;
    }

    auto* v = allocate();
    v->note = note;
    v->velocity = static_cast<float>(velocity) / 127.0f;
    v->age = age_++;
    v->active = true;

    v->osc.setWaveform(Waveform::Saw);
    v->sub.setWaveform(Waveform::Square);
    tuneVoice(*v);

    v->osc.reset(0.0);
    v->sub.reset(0.25);

    v->filter.reset();
    v->filter.setCutoff(cutoff_);
    v->filter.setResonance(resonance_);

    v->env.reset();
    v->env.setParameters(0.01f, 0.23f, 0.72f, 0.45f);
    v->env.noteOn();
}

void PolysixEngine::noteOff(std::uint8_t note) noexcept {
    for (auto& v : voices_) {
        if (v.active && v.note == note)
            v.env.noteOff();
    }
}

void PolysixEngine::controlChange(std::uint8_t cc, std::uint8_t value) noexcept {
    const float n = static_cast<float>(value) / 127.0f;

    if (cc == 74) {
        cutoff_ = 60.0f * std::pow(18000.0f / 60.0f, n);
    } else if (cc == 71) {
        resonance_ = std::clamp(n * 0.95f, 0.0f, 0.95f);
    }
}

void PolysixEngine::pitchBend(std::uint16_t value14) noexcept {
    bendSemis_ = ((static_cast<int>(value14) - 8192) / 8192.0f) * 2.0f;

    for (auto& v : voices_) {
        if (v.active)
            tuneVoice(v);
    }
}

void PolysixEngine::render(float* out, std::size_t frames) noexcept {
    if (!out) return;

    for (std::size_t i = 0; i < frames; ++i) {
        float s = 0.0f;

        for (auto& v : voices_) {
            if (!v.active) continue;

            v.filter.setCutoff(cutoff_);
            v.filter.setResonance(resonance_);

            const float src =
                v.osc.process() * 0.76f +
                v.sub.process() * 0.24f;

            const float e = v.env.process();
            s += v.filter.processLowPass(src)
               * e
               * v.velocity
               * 0.16f;

            if (!v.env.isActive())
                v.active = false;
        }

        s = std::tanh(s);

        out[i*2] = s;
        out[i*2 + 1] = s;
    }
}

void PolysixEngine::allNotesOff() noexcept {
    for (auto& v : voices_) {
        v.env.reset();
        v.active = false;
    }
}

} // namespace kp
