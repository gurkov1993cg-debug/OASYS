#pragma once
#include <cstddef>
#include <cstdint>

namespace kp {

enum class EngineType : std::uint8_t {
    Al1 = 0,
    Polysix = 1,
    Cx3 = 2
};

inline const char* engineTypeName(EngineType t) noexcept {
    switch (t) {
        case EngineType::Al1: return "AL-1";
        case EngineType::Polysix: return "PolysixEX";
        case EngineType::Cx3: return "CX-3";
    }
    return "AL-1";
}

class IEngine {
public:
    virtual ~IEngine() = default;

    virtual EngineType type() const noexcept = 0;
    virtual void setSampleRate(double sampleRate) noexcept = 0;
    virtual void noteOn(std::uint8_t note, std::uint8_t velocity) noexcept = 0;
    virtual void noteOff(std::uint8_t note) noexcept = 0;
    virtual void controlChange(std::uint8_t cc, std::uint8_t value) noexcept = 0;
    virtual void pitchBend(std::uint16_t value14) noexcept = 0;
    virtual void render(float* interleavedStereo, std::size_t frames) noexcept = 0;
    virtual void allNotesOff() noexcept = 0;

    // Engine-specific real DSP parameters. Parameter IDs are declared by each engine.
    virtual void setParameter(std::uint32_t parameterId, float value) noexcept = 0;
    virtual float getParameter(std::uint32_t parameterId) const noexcept = 0;
};

} // namespace kp
