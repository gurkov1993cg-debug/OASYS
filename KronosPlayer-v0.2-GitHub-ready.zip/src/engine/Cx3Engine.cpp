#include "engine/Cx3Engine.h"
#include <algorithm>
#include <cmath>

namespace kp {

static constexpr double kTwoPi = 6.2831853071795864769;

double Cx3Engine::noteHz(double note) noexcept {
    return 440.0 * std::pow(2.0, (note - 69.0) / 12.0);
}

void Cx3Engine::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;

    for (auto& v : voices_) {
        v.env.setSampleRate(sampleRate_);
        v.env.setParameters(0.002f, 0.01f, 1.0f, 0.025f);
    }
}

Cx3Engine::OVoice* Cx3Engine::allocate() noexcept {
    for (auto& v : voices_) {
        if (!v.active)
            return &v;
    }

    OVoice* oldest = &voices_[0];
    for (auto& v : voices_) {
        if (v.age < oldest->age)
            oldest = &v;
    }
    return oldest;
}

void Cx3Engine::noteOn(std::uint8_t note, std::uint8_t velocity) noexcept {
    if (velocity == 0) {
        noteOff(note);
        return;
    }

    auto* v = allocate();
    v->note = note;
    v->velocity = static_cast<float>(velocity) / 127.0f;
    v->age = age_++;
    v->active = true;
    v->phase.fill(0.0);

    v->env.reset();
    v->env.setParameters(0.002f, 0.01f, 1.0f, 0.025f);
    v->env.noteOn();
}

void Cx3Engine::noteOff(std::uint8_t note) noexcept {
    for (auto& v : voices_) {
        if (v.active && v.note == note)
            v.env.noteOff();
    }
}

void Cx3Engine::controlChange(std::uint8_t cc, std::uint8_t value) noexcept {
    // CC20..28 directly control the 9 drawbars.
    if (cc >= 20 && cc <= 28) {
        drawbars_[cc - 20] = static_cast<float>(value) / 127.0f;
    }
}

void Cx3Engine::pitchBend(std::uint16_t value14) noexcept {
    bendSemis_ = ((static_cast<int>(value14) - 8192) / 8192.0f) * 2.0f;
}

void Cx3Engine::render(float* out, std::size_t frames) noexcept {
    if (!out) return;

    // Tonewheel harmonic ratios for 16', 5 1/3', 8', 4', 2 2/3', 2', 1 3/5', 1 1/3', 1'
    static constexpr double ratios[9] = {
        0.5, 1.5, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0
    };

    for (std::size_t i = 0; i < frames; ++i) {
        float mix = 0.0f;

        for (auto& v : voices_) {
            if (!v.active) continue;

            const double baseHz = noteHz(static_cast<double>(v.note) + bendSemis_);
            double sample = 0.0;
            double norm = 0.0;

            for (int h = 0; h < 9; ++h) {
                const double hz = baseHz * ratios[h];
                if (hz < sampleRate_ * 0.47) {
                    sample += std::sin(kTwoPi * v.phase[h]) * drawbars_[h];
                    norm += drawbars_[h];

                    v.phase[h] += hz / sampleRate_;
                    v.phase[h] -= std::floor(v.phase[h]);
                }
            }

            if (norm > 0.0)
                sample /= norm;

            const float e = v.env.process();
            mix += static_cast<float>(sample)
                 * e
                 * (0.55f + v.velocity * 0.45f)
                 * 0.22f;

            if (!v.env.isActive())
                v.active = false;
        }

        mix = std::tanh(mix);

        out[i*2] = mix;
        out[i*2 + 1] = mix;
    }
}

void Cx3Engine::allNotesOff() noexcept {
    for (auto& v : voices_) {
        v.env.reset();
        v.active = false;
    }
}

} // namespace kp
