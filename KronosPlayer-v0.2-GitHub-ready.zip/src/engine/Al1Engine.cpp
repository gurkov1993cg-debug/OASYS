#include "engine/Al1Engine.h"
#include <algorithm>
#include <cmath>

namespace kp {

void Al1Engine::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;
    for (auto& v : voices_)
        v.setSampleRate(sampleRate_);
}

Voice* Al1Engine::allocateVoice() noexcept {
    for (auto& v : voices_) {
        if (!v.active())
            return &v;
    }

    Voice* oldest = &voices_[0];
    for (auto& v : voices_) {
        if (v.age() < oldest->age())
            oldest = &v;
    }

    oldest->forceStop();
    return oldest;
}

void Al1Engine::noteOn(std::uint8_t note, std::uint8_t velocity) noexcept {
    if (velocity == 0) {
        noteOff(note);
        return;
    }

    auto* v = allocateVoice();
    v->start(note, velocity, patch_, ageCounter_++, bendSemis_);
}

void Al1Engine::noteOff(std::uint8_t note) noexcept {
    for (auto& v : voices_)
        v.release(note);
}

void Al1Engine::controlChange(std::uint8_t cc, std::uint8_t value) noexcept {
    const float n = static_cast<float>(value) / 127.0f;

    if (cc == 74) {
        const double minHz = 40.0;
        const double maxHz = 18000.0;
        patch_.cutoffHz =
            static_cast<float>(minHz * std::pow(maxHz / minHz, n));
    } else if (cc == 71) {
        patch_.resonance = std::clamp(n * 0.96f, 0.0f, 0.96f);
    }
}

void Al1Engine::pitchBend(std::uint16_t value14) noexcept {
    const float normalized =
        (static_cast<int>(value14) - 8192) / 8192.0f;

    bendSemis_ = normalized * 2.0f;

    for (auto& v : voices_) {
        if (v.active())
            v.updatePitch(patch_, bendSemis_);
    }
}

void Al1Engine::render(float* out, std::size_t frames) noexcept {
    if (!out) return;

    for (std::size_t i = 0; i < frames; ++i) {
        float s = 0.0f;
        for (auto& v : voices_)
            s += v.process(patch_);

        s = std::tanh(s);

        out[i*2] = s;
        out[i*2 + 1] = s;
    }
}

void Al1Engine::allNotesOff() noexcept {
    for (auto& v : voices_)
        v.forceStop();
}

} // namespace kp
