#include "engine/Al1Engine.h"
#include <algorithm>
#include <cmath>

namespace kp {

void Al1Engine::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;
    for (auto& v : voices_)
        v.setSampleRate(sampleRate_);
}

Voice* Al1Engine::allocateVoice() noexcept {
    for (auto& v : voices_) {
        if (!v.active())
            return &v;
    }

    Voice* oldest = &voices_[0];
    for (auto& v : voices_) {
        if (v.age() < oldest->age())
            oldest = &v;
    }

    oldest->forceStop();
    return oldest;
}

void Al1Engine::noteOn(std::uint8_t note, std::uint8_t velocity) noexcept {
    if (velocity == 0) {
        noteOff(note);
        return;
    }

    auto* v = allocateVoice();
    v->start(
        note,
        velocity,
        patch_,
        ageCounter_++,
        bendSemis_,
        lastNoteForGlide_);

    lastNoteForGlide_ = static_cast<float>(note);
}

void Al1Engine::noteOff(std::uint8_t note) noexcept {
    for (auto& v : voices_)
        v.release(note);
}

void Al1Engine::controlChange(std::uint8_t cc, std::uint8_t value) noexcept {
    const float n = static_cast<float>(value) / 127.0f;

    if (cc == 1) {
        modWheel_ = n;
    }
    else if (cc == 74) {
        const double minHz = 40.0;
        const double maxHz = 18000.0;
        patch_.filter1CutoffHz =
            static_cast<float>(minHz * std::pow(maxHz / minHz, n));
    }
    else if (cc == 71) {
        patch_.filter1Resonance =
            std::clamp(n * 0.96f, 0.0f, 0.96f);
    }
}

void Al1Engine::pitchBend(std::uint16_t value14) noexcept {
    const float normalized =
        (static_cast<int>(value14) - 8192) / 8192.0f;

    bendSemis_ = normalized * 2.0f;
}

void Al1Engine::channelPressure(std::uint8_t value) noexcept {
    aftertouch_ =
        std::clamp(static_cast<float>(value) / 127.0f, 0.0f, 1.0f);
}

void Al1Engine::setParameter(std::uint32_t parameterId,
                             float value) noexcept {
    const auto p = static_cast<Al1Parameter>(parameterId);

    switch (p) {
        case Al1Parameter::Osc1Wave:
            patch_.osc1Wave =
                static_cast<Waveform>(
                    std::clamp((int)std::lround(value), 0, 3));
            break;
        case Al1Parameter::Osc1Level:
            patch_.osc1Level = std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::Osc1Semitone:
            patch_.osc1Semitone =
                std::clamp((int)std::lround(value), -48, 48);
            break;
        case Al1Parameter::Osc1DetuneCents:
            patch_.osc1DetuneCents =
                std::clamp(value, -100.0f, 100.0f);
            break;

        case Al1Parameter::Osc2Wave:
            patch_.osc2Wave =
                static_cast<Waveform>(
                    std::clamp((int)std::lround(value), 0, 3));
            break;
        case Al1Parameter::Osc2Level:
            patch_.osc2Level = std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::Osc2Semitone:
            patch_.osc2Semitone =
                std::clamp((int)std::lround(value), -48, 48);
            break;
        case Al1Parameter::Osc2DetuneCents:
            patch_.osc2DetuneCents =
                std::clamp(value, -100.0f, 100.0f);
            break;

        case Al1Parameter::HardSync:
            patch_.hardSync = value >= 0.5f;
            break;
        case Al1Parameter::RingMod:
            patch_.ringMod = std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::SubLevel:
            patch_.subLevel = std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::NoiseLevel:
            patch_.noiseLevel = std::clamp(value, 0.0f, 1.0f);
            break;

        case Al1Parameter::UnisonVoices:
            patch_.unisonVoices =
                std::clamp((int)std::lround(value), 1, Voice::kMaxUnison);
            break;
        case Al1Parameter::UnisonSpreadCents:
            patch_.unisonSpreadCents =
                std::clamp(value, 0.0f, 50.0f);
            break;
        case Al1Parameter::PortamentoSeconds:
            patch_.portamentoSeconds =
                std::clamp(value, 0.0f, 5.0f);
            break;

        case Al1Parameter::PitchEgAmountSemis:
            patch_.pitchEgAmountSemis =
                std::clamp(value, -24.0f, 24.0f);
            break;
        case Al1Parameter::PitchEgAttack:
            patch_.pitchEgAttack =
                std::clamp(value, 0.001f, 10.0f);
            break;
        case Al1Parameter::PitchEgDecay:
            patch_.pitchEgDecay =
                std::clamp(value, 0.001f, 10.0f);
            break;
        case Al1Parameter::PitchEgRelease:
            patch_.pitchEgRelease =
                std::clamp(value, 0.001f, 10.0f);
            break;

        case Al1Parameter::Filter1Mode:
            patch_.filter1Mode =
                static_cast<FilterMode>(
                    std::clamp((int)std::lround(value), 0, 2));
            break;
        case Al1Parameter::Filter1Cutoff:
            patch_.filter1CutoffHz =
                std::clamp(value, 20.0f, 18000.0f);
            break;
        case Al1Parameter::Filter1Resonance:
            patch_.filter1Resonance =
                std::clamp(value, 0.0f, 0.985f);
            break;

        case Al1Parameter::Filter2Mode:
            patch_.filter2Mode =
                static_cast<FilterMode>(
                    std::clamp((int)std::lround(value), 0, 2));
            break;
        case Al1Parameter::Filter2Cutoff:
            patch_.filter2CutoffHz =
                std::clamp(value, 20.0f, 18000.0f);
            break;
        case Al1Parameter::Filter2Resonance:
            patch_.filter2Resonance =
                std::clamp(value, 0.0f, 0.985f);
            break;

        case Al1Parameter::FilterRouting:
            patch_.filterRouting =
                static_cast<FilterRouting>(
                    std::clamp((int)std::lround(value), 0, 1));
            break;
        case Al1Parameter::ParallelBalance:
            patch_.parallelBalance =
                std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::FilterKeyTrack:
            patch_.filterKeyTrack =
                std::clamp(value, -2.0f, 2.0f);
            break;
        case Al1Parameter::FilterEgAmountOctaves:
            patch_.filterEgAmountOctaves =
                std::clamp(value, -8.0f, 8.0f);
            break;
        case Al1Parameter::VelocityToFilterOctaves:
            patch_.velocityToFilterOctaves =
                std::clamp(value, -4.0f, 4.0f);
            break;
        case Al1Parameter::AftertouchToFilterOctaves:
            patch_.aftertouchToFilterOctaves =
                std::clamp(value, -4.0f, 4.0f);
            break;

        case Al1Parameter::FilterEgAttack:
            patch_.filterEgAttack =
                std::clamp(value, 0.001f, 10.0f);
            break;
        case Al1Parameter::FilterEgDecay:
            patch_.filterEgDecay =
                std::clamp(value, 0.001f, 10.0f);
            break;
        case Al1Parameter::FilterEgSustain:
            patch_.filterEgSustain =
                std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::FilterEgRelease:
            patch_.filterEgRelease =
                std::clamp(value, 0.001f, 15.0f);
            break;

        case Al1Parameter::AmpAttack:
            patch_.ampAttack =
                std::clamp(value, 0.001f, 10.0f);
            break;
        case Al1Parameter::AmpDecay:
            patch_.ampDecay =
                std::clamp(value, 0.001f, 10.0f);
            break;
        case Al1Parameter::AmpSustain:
            patch_.ampSustain =
                std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::AmpRelease:
            patch_.ampRelease =
                std::clamp(value, 0.001f, 15.0f);
            break;

        case Al1Parameter::LfoWave:
            patch_.lfoWave =
                static_cast<Waveform>(
                    std::clamp((int)std::lround(value), 0, 3));
            break;
        case Al1Parameter::LfoRateHz:
            patch_.lfoRateHz =
                std::clamp(value, 0.02f, 30.0f);
            break;
        case Al1Parameter::LfoPitchSemis:
            patch_.lfoPitchSemis =
                std::clamp(value, 0.0f, 12.0f);
            break;
        case Al1Parameter::LfoFilterOctaves:
            patch_.lfoFilterOctaves =
                std::clamp(value, -6.0f, 6.0f);
            break;
        case Al1Parameter::LfoAmpDepth:
            patch_.lfoAmpDepth =
                std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::ModWheelToLfo:
            patch_.modWheelToLfo =
                std::clamp(value, 0.0f, 1.0f);
            break;

        case Al1Parameter::Drive:
            patch_.drive =
                std::clamp(value, 1.0f, 12.0f);
            break;
        case Al1Parameter::MasterGain:
            patch_.masterGain =
                std::clamp(value, 0.0f, 1.0f);
            break;

        case Al1Parameter::Count:
            break;
    }
}

float Al1Engine::getParameter(std::uint32_t parameterId) const noexcept {
    const auto p = static_cast<Al1Parameter>(parameterId);

    switch (p) {
        case Al1Parameter::Osc1Wave: return (float)patch_.osc1Wave;
        case Al1Parameter::Osc1Level: return patch_.osc1Level;
        case Al1Parameter::Osc1Semitone: return (float)patch_.osc1Semitone;
        case Al1Parameter::Osc1DetuneCents: return patch_.osc1DetuneCents;

        case Al1Parameter::Osc2Wave: return (float)patch_.osc2Wave;
        case Al1Parameter::Osc2Level: return patch_.osc2Level;
        case Al1Parameter::Osc2Semitone: return (float)patch_.osc2Semitone;
        case Al1Parameter::Osc2DetuneCents: return patch_.osc2DetuneCents;

        case Al1Parameter::HardSync: return patch_.hardSync ? 1.0f : 0.0f;
        case Al1Parameter::RingMod: return patch_.ringMod;
        case Al1Parameter::SubLevel: return patch_.subLevel;
        case Al1Parameter::NoiseLevel: return patch_.noiseLevel;

        case Al1Parameter::UnisonVoices: return (float)patch_.unisonVoices;
        case Al1Parameter::UnisonSpreadCents: return patch_.unisonSpreadCents;
        case Al1Parameter::PortamentoSeconds: return patch_.portamentoSeconds;

        case Al1Parameter::PitchEgAmountSemis: return patch_.pitchEgAmountSemis;
        case Al1Parameter::PitchEgAttack: return patch_.pitchEgAttack;
        case Al1Parameter::PitchEgDecay: return patch_.pitchEgDecay;
        case Al1Parameter::PitchEgRelease: return patch_.pitchEgRelease;

        case Al1Parameter::Filter1Mode: return (float)patch_.filter1Mode;
        case Al1Parameter::Filter1Cutoff: return patch_.filter1CutoffHz;
        case Al1Parameter::Filter1Resonance: return patch_.filter1Resonance;

        case Al1Parameter::Filter2Mode: return (float)patch_.filter2Mode;
        case Al1Parameter::Filter2Cutoff: return patch_.filter2CutoffHz;
        case Al1Parameter::Filter2Resonance: return patch_.filter2Resonance;

        case Al1Parameter::FilterRouting: return (float)patch_.filterRouting;
        case Al1Parameter::ParallelBalance: return patch_.parallelBalance;
        case Al1Parameter::FilterKeyTrack: return patch_.filterKeyTrack;
        case Al1Parameter::FilterEgAmountOctaves: return patch_.filterEgAmountOctaves;
        case Al1Parameter::VelocityToFilterOctaves: return patch_.velocityToFilterOctaves;
        case Al1Parameter::AftertouchToFilterOctaves: return patch_.aftertouchToFilterOctaves;

        case Al1Parameter::FilterEgAttack: return patch_.filterEgAttack;
        case Al1Parameter::FilterEgDecay: return patch_.filterEgDecay;
        case Al1Parameter::FilterEgSustain: return patch_.filterEgSustain;
        case Al1Parameter::FilterEgRelease: return patch_.filterEgRelease;

        case Al1Parameter::AmpAttack: return patch_.ampAttack;
        case Al1Parameter::AmpDecay: return patch_.ampDecay;
        case Al1Parameter::AmpSustain: return patch_.ampSustain;
        case Al1Parameter::AmpRelease: return patch_.ampRelease;

        case Al1Parameter::LfoWave: return (float)patch_.lfoWave;
        case Al1Parameter::LfoRateHz: return patch_.lfoRateHz;
        case Al1Parameter::LfoPitchSemis: return patch_.lfoPitchSemis;
        case Al1Parameter::LfoFilterOctaves: return patch_.lfoFilterOctaves;
        case Al1Parameter::LfoAmpDepth: return patch_.lfoAmpDepth;
        case Al1Parameter::ModWheelToLfo: return patch_.modWheelToLfo;

        case Al1Parameter::Drive: return patch_.drive;
        case Al1Parameter::MasterGain: return patch_.masterGain;

        case Al1Parameter::Count: break;
    }

    return 0.0f;
}

void Al1Engine::render(float* out, std::size_t frames) noexcept {
    if (!out)
        return;

    for (auto& v : voices_) {
        if (v.active())
            v.applyPatch(patch_);
    }

    for (std::size_t i = 0; i < frames; ++i) {
        float s = 0.0f;

        for (auto& v : voices_) {
            s += v.process(
                patch_,
                bendSemis_,
                modWheel_,
                aftertouch_);
        }

        s = std::tanh(s);
        out[i*2] = s;
        out[i*2 + 1] = s;
    }
}

void Al1Engine::allNotesOff() noexcept {
    for (auto& v : voices_)
        v.forceStop();
}

} // namespace kp
