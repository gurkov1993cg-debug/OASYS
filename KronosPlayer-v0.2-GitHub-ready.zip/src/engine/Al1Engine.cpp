#include "engine/Al1Engine.h"
#include <algorithm>
#include <cmath>

namespace kp {

void Al1Engine::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;
    for (auto& v : voices_)
        v.setSampleRate(sampleRate_);
}

Voice* Al1Engine::allocateVoice() noexcept {
    for (auto& v : voices_) {
        if (!v.active())
            return &v;
    }

    Voice* oldest = &voices_[0];
    for (auto& v : voices_) {
        if (v.age() < oldest->age())
            oldest = &v;
    }

    oldest->forceStop();
    return oldest;
}

void Al1Engine::noteOn(std::uint8_t note, std::uint8_t velocity) noexcept {
    if (velocity == 0) {
        noteOff(note);
        return;
    }

    auto* v = allocateVoice();
    v->start(note, velocity, patch_, ageCounter_++, bendSemis_);
}

void Al1Engine::noteOff(std::uint8_t note) noexcept {
    for (auto& v : voices_)
        v.release(note);
}

void Al1Engine::controlChange(std::uint8_t cc, std::uint8_t value) noexcept {
    const float n = static_cast<float>(value) / 127.0f;

    if (cc == 74) {
        const double minHz = 40.0;
        const double maxHz = 18000.0;
        patch_.cutoffHz = static_cast<float>(minHz * std::pow(maxHz / minHz, n));
    } else if (cc == 71) {
        patch_.resonance = std::clamp(n * 0.96f, 0.0f, 0.96f);
    }
}

void Al1Engine::pitchBend(std::uint16_t value14) noexcept {
    const float normalized = (static_cast<int>(value14) - 8192) / 8192.0f;
    bendSemis_ = normalized * 2.0f;
}

void Al1Engine::setParameter(std::uint32_t parameterId, float value) noexcept {
    const auto p = static_cast<Al1Parameter>(parameterId);

    switch (p) {
        case Al1Parameter::Osc1Wave:
            patch_.osc1Wave = static_cast<Waveform>(std::clamp(static_cast<int>(std::lround(value)), 0, 3));
            break;
        case Al1Parameter::Osc1Level:
            patch_.osc1Level = std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::Osc1Semitone:
            patch_.osc1Semitone = std::clamp(static_cast<int>(std::lround(value)), -48, 48);
            break;
        case Al1Parameter::Osc1DetuneCents:
            patch_.osc1DetuneCents = std::clamp(value, -100.0f, 100.0f);
            break;
        case Al1Parameter::Osc2Wave:
            patch_.osc2Wave = static_cast<Waveform>(std::clamp(static_cast<int>(std::lround(value)), 0, 3));
            break;
        case Al1Parameter::Osc2Level:
            patch_.osc2Level = std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::Osc2Semitone:
            patch_.osc2Semitone = std::clamp(static_cast<int>(std::lround(value)), -48, 48);
            break;
        case Al1Parameter::Osc2DetuneCents:
            patch_.osc2DetuneCents = std::clamp(value, -100.0f, 100.0f);
            break;
        case Al1Parameter::FilterCutoff:
            patch_.cutoffHz = std::clamp(value, 20.0f, 18000.0f);
            break;
        case Al1Parameter::FilterResonance:
            patch_.resonance = std::clamp(value, 0.0f, 0.98f);
            break;
        case Al1Parameter::AmpAttack:
            patch_.ampAttack = std::clamp(value, 0.001f, 10.0f);
            break;
        case Al1Parameter::AmpDecay:
            patch_.ampDecay = std::clamp(value, 0.001f, 10.0f);
            break;
        case Al1Parameter::AmpSustain:
            patch_.ampSustain = std::clamp(value, 0.0f, 1.0f);
            break;
        case Al1Parameter::AmpRelease:
            patch_.ampRelease = std::clamp(value, 0.001f, 15.0f);
            break;
        case Al1Parameter::MasterGain:
            patch_.masterGain = std::clamp(value, 0.0f, 1.0f);
            break;
    }
}

float Al1Engine::getParameter(std::uint32_t parameterId) const noexcept {
    const auto p = static_cast<Al1Parameter>(parameterId);

    switch (p) {
        case Al1Parameter::Osc1Wave: return static_cast<float>(patch_.osc1Wave);
        case Al1Parameter::Osc1Level: return patch_.osc1Level;
        case Al1Parameter::Osc1Semitone: return static_cast<float>(patch_.osc1Semitone);
        case Al1Parameter::Osc1DetuneCents: return patch_.osc1DetuneCents;
        case Al1Parameter::Osc2Wave: return static_cast<float>(patch_.osc2Wave);
        case Al1Parameter::Osc2Level: return patch_.osc2Level;
        case Al1Parameter::Osc2Semitone: return static_cast<float>(patch_.osc2Semitone);
        case Al1Parameter::Osc2DetuneCents: return patch_.osc2DetuneCents;
        case Al1Parameter::FilterCutoff: return patch_.cutoffHz;
        case Al1Parameter::FilterResonance: return patch_.resonance;
        case Al1Parameter::AmpAttack: return patch_.ampAttack;
        case Al1Parameter::AmpDecay: return patch_.ampDecay;
        case Al1Parameter::AmpSustain: return patch_.ampSustain;
        case Al1Parameter::AmpRelease: return patch_.ampRelease;
        case Al1Parameter::MasterGain: return patch_.masterGain;
    }
    return 0.0f;
}

void Al1Engine::render(float* out, std::size_t frames) noexcept {
    if (!out) return;

    for (auto& v : voices_) {
        if (v.active())
            v.applyPatch(patch_, bendSemis_);
    }

    for (std::size_t i = 0; i < frames; ++i) {
        float s = 0.0f;
        for (auto& v : voices_)
            s += v.process(patch_);

        s = std::tanh(s);
        out[i*2] = s;
        out[i*2 + 1] = s;
    }
}

void Al1Engine::allNotesOff() noexcept {
    for (auto& v : voices_)
        v.forceStop();
}

} // namespace kp
