#pragma once
#include "engine/IEngine.h"
#include <memory>

namespace kp {

std::unique_ptr<IEngine> createEngine(EngineType type);

} // namespace kp
