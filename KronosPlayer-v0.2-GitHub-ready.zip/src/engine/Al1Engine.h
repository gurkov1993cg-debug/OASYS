#pragma once
#include "engine/IEngine.h"
#include "engine/Al1Patch.h"
#include "engine/Voice.h"
#include <array>
#include <cstddef>
#include <cstdint>

namespace kp {

class Al1Engine final : public IEngine {
public:
    static constexpr std::size_t kMaxVoices = 32;

    EngineType type() const noexcept override { return EngineType::Al1; }

    void setSampleRate(double sampleRate) noexcept override;
    void noteOn(std::uint8_t note, std::uint8_t velocity) noexcept override;
    void noteOff(std::uint8_t note) noexcept override;
    void controlChange(std::uint8_t cc, std::uint8_t value) noexcept override;
    void pitchBend(std::uint16_t value14) noexcept override;
    void render(float* out, std::size_t frames) noexcept override;
    void allNotesOff() noexcept override;

    Al1Patch& patch() noexcept { return patch_; }
    const Al1Patch& patch() const noexcept { return patch_; }

private:
    Voice* allocateVoice() noexcept;

    double sampleRate_{48000.0};
    Al1Patch patch_{};
    std::array<Voice, kMaxVoices> voices_{};
    std::uint64_t ageCounter_{1};
    float bendSemis_{0.0f};
};

} // namespace kp
