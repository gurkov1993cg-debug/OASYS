#include "engine/Voice.h"
#include <cmath>

namespace kp {

void Voice::setSampleRate(double sr) noexcept {
    sampleRate_ = sr;
    osc1_.setSampleRate(sr);
    osc2_.setSampleRate(sr);
    env_.setSampleRate(sr);
    filter_.setSampleRate(sr);
}

double Voice::midiToHz(double note, float cents) noexcept {
    const double semis = (note - 69.0) + static_cast<double>(cents) / 100.0;
    return 440.0 * std::pow(2.0, semis / 12.0);
}

void Voice::start(std::uint8_t note,
                  std::uint8_t velocity,
                  const Al1Patch& patch,
                  std::uint64_t age,
                  float pitchBendSemis) noexcept {
    note_ = note;
    age_ = age;

    const float v = static_cast<float>(velocity) / 127.0f;
    velocityGain_ = v * v * 0.85f + v * 0.15f;

    osc1_.setWaveform(patch.osc1Wave);
    osc2_.setWaveform(patch.osc2Wave);

    updatePitch(patch, pitchBendSemis);

    osc1_.reset(0.0);
    osc2_.reset(0.25);

    filter_.reset();
    filter_.setCutoff(patch.cutoffHz);
    filter_.setResonance(patch.resonance);

    env_.reset();
    env_.setParameters(
        patch.ampAttack,
        patch.ampDecay,
        patch.ampSustain,
        patch.ampRelease
    );
    env_.noteOn();
}

void Voice::updatePitch(const Al1Patch& patch, float bendSemis) noexcept {
    osc1_.setFrequency(
        midiToHz(static_cast<double>(note_ + patch.osc1Semitone) + bendSemis,
                 patch.osc1DetuneCents)
    );

    osc2_.setFrequency(
        midiToHz(static_cast<double>(note_ + patch.osc2Semitone) + bendSemis,
                 patch.osc2DetuneCents)
    );
}

void Voice::release(std::uint8_t note) noexcept {
    if (active() && note_ == note)
        env_.noteOff();
}

void Voice::forceStop() noexcept {
    env_.reset();
    filter_.reset();
}

float Voice::process(const Al1Patch& patch) noexcept {
    if (!active())
        return 0.0f;

    filter_.setCutoff(patch.cutoffHz);
    filter_.setResonance(patch.resonance);

    const float s =
        osc1_.process() * patch.osc1Level +
        osc2_.process() * patch.osc2Level;

    return filter_.processLowPass(s)
         * env_.process()
         * velocityGain_
         * patch.masterGain;
}

} // namespace kp
