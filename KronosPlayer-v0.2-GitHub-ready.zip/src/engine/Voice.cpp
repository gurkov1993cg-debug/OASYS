#include "engine/Voice.h"
#include <algorithm>
#include <cmath>

namespace kp {

static constexpr double kTwoPi = 6.2831853071795864769;

void Voice::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;

    for (auto& o : osc1_) o.setSampleRate(sampleRate_);
    for (auto& o : osc2_) o.setSampleRate(sampleRate_);

    subOsc_.setSampleRate(sampleRate_);

    ampEnv_.setSampleRate(sampleRate_);
    filterEnv_.setSampleRate(sampleRate_);
    pitchEnv_.setSampleRate(sampleRate_);

    filter1_.setSampleRate(sampleRate_);
    filter2_.setSampleRate(sampleRate_);
}

double Voice::midiToHz(double note, float cents) noexcept {
    const double semis = (note - 69.0) + static_cast<double>(cents) / 100.0;
    return 440.0 * std::pow(2.0, semis / 12.0);
}

float Voice::clampCutoff(float hz, double sampleRate) noexcept {
    return std::clamp(hz, 20.0f, static_cast<float>(sampleRate * 0.45));
}

float Voice::lfoValue(Waveform wave, double phase) noexcept {
    phase -= std::floor(phase);

    switch (wave) {
        case Waveform::Sine:
            return static_cast<float>(std::sin(kTwoPi * phase));
        case Waveform::Triangle:
            return static_cast<float>(1.0 - 4.0 * std::abs(phase - 0.5));
        case Waveform::Saw:
            return static_cast<float>(2.0 * phase - 1.0);
        case Waveform::Square:
            return phase < 0.5 ? 1.0f : -1.0f;
    }

    return 0.0f;
}

float Voice::processFilter(SvfFilter& filter,
                           float input,
                           FilterMode mode) noexcept {
    return filter.process(input, mode);
}

std::uint32_t Voice::nextNoise() noexcept {
    noiseState_ ^= noiseState_ << 13;
    noiseState_ ^= noiseState_ >> 17;
    noiseState_ ^= noiseState_ << 5;
    return noiseState_;
}

void Voice::start(std::uint8_t note,
                  std::uint8_t velocity,
                  const Al1Patch& patch,
                  std::uint64_t age,
                  float pitchBendSemis,
                  float glideStartNote) noexcept {
    note_ = note;
    age_ = age;

    velocity_ = static_cast<float>(velocity) / 127.0f;
    velocityGain_ = velocity_ * velocity_ * 0.82f + velocity_ * 0.18f;

    currentMidiNote_ =
        patch.portamentoSeconds > 0.0005f
            ? glideStartNote
            : static_cast<float>(note_);

    for (int i = 0; i < kMaxUnison; ++i) {
        osc1_[i].reset(0.11 * i);
        osc2_[i].reset(0.25 + 0.13 * i);
    }

    subOsc_.reset(0.0);
    filter1_.reset();
    filter2_.reset();

    ampEnv_.reset();
    filterEnv_.reset();
    pitchEnv_.reset();

    lfoPhase_ = 0.0;

    noiseState_ =
        0x9E3779B9u ^
        (static_cast<std::uint32_t>(note_) * 2654435761u) ^
        static_cast<std::uint32_t>(age_);

    applyPatch(patch);

    ampEnv_.noteOn();
    filterEnv_.noteOn();
    pitchEnv_.noteOn();

    (void)pitchBendSemis;
}

void Voice::applyPatch(const Al1Patch& patch) noexcept {
    for (auto& o : osc1_)
        o.setWaveform(patch.osc1Wave);

    for (auto& o : osc2_)
        o.setWaveform(patch.osc2Wave);

    subOsc_.setWaveform(Waveform::Square);

    ampEnv_.setParameters(
        patch.ampAttack,
        patch.ampDecay,
        patch.ampSustain,
        patch.ampRelease);

    filterEnv_.setParameters(
        patch.filterEgAttack,
        patch.filterEgDecay,
        patch.filterEgSustain,
        patch.filterEgRelease);

    pitchEnv_.setParameters(
        patch.pitchEgAttack,
        patch.pitchEgDecay,
        0.0f,
        patch.pitchEgRelease);

    filter1_.setResonance(patch.filter1Resonance);
    filter2_.setResonance(patch.filter2Resonance);
}

void Voice::release(std::uint8_t note) noexcept {
    if (active() && note_ == note) {
        ampEnv_.noteOff();
        filterEnv_.noteOff();
        pitchEnv_.noteOff();
    }
}

void Voice::forceStop() noexcept {
    ampEnv_.reset();
    filterEnv_.reset();
    pitchEnv_.reset();

    filter1_.reset();
    filter2_.reset();
}

float Voice::process(const Al1Patch& patch,
                     float pitchBendSemis,
                     float modWheel,
                     float aftertouch) noexcept {
    if (!active())
        return 0.0f;

    // Portamento follows the target note exponentially.
    if (patch.portamentoSeconds <= 0.0005f) {
        currentMidiNote_ = static_cast<float>(note_);
    } else {
        const float coeff =
            1.0f - std::exp(
                -1.0f /
                std::max(1.0f,
                    patch.portamentoSeconds * static_cast<float>(sampleRate_)));

        currentMidiNote_ +=
            (static_cast<float>(note_) - currentMidiNote_) * coeff;
    }

    const float pitchEg = pitchEnv_.process();
    const float filterEg = filterEnv_.process();
    const float ampEg = ampEnv_.process();

    const float lfo = lfoValue(patch.lfoWave, lfoPhase_);
    lfoPhase_ += static_cast<double>(patch.lfoRateHz) / sampleRate_;
    lfoPhase_ -= std::floor(lfoPhase_);

    const float lfoScale =
        std::clamp(
            (1.0f - patch.modWheelToLfo) +
            patch.modWheelToLfo * modWheel,
            0.0f,
            1.0f);

    const float pitchModSemis =
        pitchBendSemis +
        pitchEg * patch.pitchEgAmountSemis +
        lfo * patch.lfoPitchSemis * lfoScale;

    const int unisonCount =
        std::clamp(patch.unisonVoices, 1, kMaxUnison);

    float osc1Sum = 0.0f;
    float osc2Sum = 0.0f;
    float ringSum = 0.0f;

    for (int i = 0; i < unisonCount; ++i) {
        float unisonPos = 0.0f;
        if (unisonCount == 2)
            unisonPos = (i == 0) ? -1.0f : 1.0f;
        else if (unisonCount == 3)
            unisonPos = static_cast<float>(i - 1);

        const float spread =
            patch.unisonSpreadCents * unisonPos;

        const double note1 =
            currentMidiNote_ +
            static_cast<float>(patch.osc1Semitone) +
            pitchModSemis;

        const double note2 =
            currentMidiNote_ +
            static_cast<float>(patch.osc2Semitone) +
            pitchModSemis;

        osc1_[i].setFrequency(
            midiToHz(note1, patch.osc1DetuneCents + spread));

        osc2_[i].setFrequency(
            midiToHz(note2, patch.osc2DetuneCents - spread));

        const float a = osc1_[i].process();

        if (patch.hardSync && osc1_[i].didWrap())
            osc2_[i].reset(0.0);

        const float b = osc2_[i].process();

        osc1Sum += a;
        osc2Sum += b;
        ringSum += a * b;
    }

    const float invUnison = 1.0f / static_cast<float>(unisonCount);
    osc1Sum *= invUnison;
    osc2Sum *= invUnison;
    ringSum *= invUnison;

    subOsc_.setFrequency(
        midiToHz(
            currentMidiNote_ - 12.0f + pitchModSemis,
            0.0f));

    const float sub = subOsc_.process();

    const float noise =
        (static_cast<float>(nextNoise() & 0xFFFFu) / 32767.5f) - 1.0f;

    const float normalMix =
        osc1Sum * patch.osc1Level +
        osc2Sum * patch.osc2Level;

    const float oscMix =
        normalMix * (1.0f - patch.ringMod) +
        ringSum * patch.ringMod +
        sub * patch.subLevel +
        noise * patch.noiseLevel;

    const float noteTrackOct =
        ((static_cast<float>(note_) - 60.0f) / 12.0f)
        * patch.filterKeyTrack;

    const float velocityOct =
        (velocity_ - 0.5f) * 2.0f
        * patch.velocityToFilterOctaves;

    const float aftertouchOct =
        aftertouch * patch.aftertouchToFilterOctaves;

    const float modOct =
        noteTrackOct +
        filterEg * patch.filterEgAmountOctaves +
        lfo * patch.lfoFilterOctaves * lfoScale +
        velocityOct +
        aftertouchOct;

    const float cutoffMultiplier =
        std::pow(2.0f, modOct);

    filter1_.setCutoff(
        clampCutoff(
            patch.filter1CutoffHz * cutoffMultiplier,
            sampleRate_));

    filter2_.setCutoff(
        clampCutoff(
            patch.filter2CutoffHz * cutoffMultiplier,
            sampleRate_));

    filter1_.setResonance(patch.filter1Resonance);
    filter2_.setResonance(patch.filter2Resonance);

    float filtered = 0.0f;

    if (patch.filterRouting == FilterRouting::Serial) {
        const float first =
            processFilter(filter1_, oscMix, patch.filter1Mode);
        filtered =
            processFilter(filter2_, first, patch.filter2Mode);
    } else {
        const float a =
            processFilter(filter1_, oscMix, patch.filter1Mode);
        const float b =
            processFilter(filter2_, oscMix, patch.filter2Mode);

        filtered =
            a * (1.0f - patch.parallelBalance) +
            b * patch.parallelBalance;
    }

    const float drive =
        std::clamp(patch.drive, 1.0f, 12.0f);

    const float driven =
        std::tanh(filtered * drive)
        / std::tanh(drive);

    const float ampLfo =
        std::clamp(
            1.0f + lfo * patch.lfoAmpDepth * lfoScale,
            0.0f,
            2.0f);

    return driven
         * ampEg
         * ampLfo
         * velocityGain_
         * patch.masterGain;
}

} // namespace kp
