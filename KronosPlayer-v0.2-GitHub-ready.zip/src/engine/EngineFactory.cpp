#include "engine/EngineFactory.h"
#include "engine/Al1Engine.h"
#include "engine/PolysixEngine.h"
#include "engine/Cx3Engine.h"

namespace kp {

std::unique_ptr<IEngine> createEngine(EngineType type) {
    switch (type) {
        case EngineType::Al1:
            return std::make_unique<Al1Engine>();
        case EngineType::Polysix:
            return std::make_unique<PolysixEngine>();
        case EngineType::Cx3:
            return std::make_unique<Cx3Engine>();
    }

    return std::make_unique<Al1Engine>();
}

} // namespace kp
