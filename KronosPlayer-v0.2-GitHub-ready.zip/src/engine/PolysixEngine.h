#pragma once
#include "engine/IEngine.h"
#include "dsp/Oscillator.h"
#include "dsp/Adsr.h"
#include "dsp/SvfFilter.h"
#include <array>

namespace kp {

class PolysixEngine final : public IEngine {
public:
    EngineType type() const noexcept override { return EngineType::Polysix; }

    void setSampleRate(double sampleRate) noexcept override;
    void noteOn(std::uint8_t note, std::uint8_t velocity) noexcept override;
    void noteOff(std::uint8_t note) noexcept override;
    void controlChange(std::uint8_t cc, std::uint8_t value) noexcept override;
    void pitchBend(std::uint16_t value14) noexcept override;
    void render(float* out, std::size_t frames) noexcept override;
    void allNotesOff() noexcept override;

private:
    struct PVoice {
        Oscillator osc;
        Oscillator sub;
        Adsr env;
        SvfFilter filter;

        std::uint8_t note{0};
        float velocity{0.0f};
        std::uint64_t age{0};
        bool active{false};
    };

    static double noteHz(double note) noexcept;
    void tuneVoice(PVoice& v) noexcept;
    PVoice* allocate() noexcept;

    double sampleRate_{48000.0};
    std::array<PVoice, 24> voices_{};
    std::uint64_t age_{1};

    float cutoff_{5200.0f};
    float resonance_{0.22f};
    float bendSemis_{0.0f};
};

} // namespace kp
