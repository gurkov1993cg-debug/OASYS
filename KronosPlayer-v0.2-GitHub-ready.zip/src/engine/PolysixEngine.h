#pragma once
#include "engine/IEngine.h"
#include "dsp/Oscillator.h"
#include "dsp/Adsr.h"
#include "dsp/SvfFilter.h"
#include <array>

namespace kp {

enum class PolysixParameter : std::uint32_t {
    Wave = 0,
    OscLevel,
    SubLevel,
    FilterCutoff,
    FilterResonance,
    AmpAttack,
    AmpDecay,
    AmpSustain,
    AmpRelease,
    MasterGain
};

class PolysixEngine final : public IEngine {
public:
    EngineType type() const noexcept override { return EngineType::Polysix; }

    void setSampleRate(double sampleRate) noexcept override;
    void noteOn(std::uint8_t note, std::uint8_t velocity) noexcept override;
    void noteOff(std::uint8_t note) noexcept override;
    void controlChange(std::uint8_t cc, std::uint8_t value) noexcept override;
    void pitchBend(std::uint16_t value14) noexcept override;
    void render(float* out, std::size_t frames) noexcept override;
    void allNotesOff() noexcept override;
    void setParameter(std::uint32_t parameterId, float value) noexcept override;
    float getParameter(std::uint32_t parameterId) const noexcept override;

private:
    struct PVoice {
        Oscillator osc;
        Oscillator sub;
        Adsr env;
        SvfFilter filter;

        std::uint8_t note{0};
        float velocity{0.0f};
        std::uint64_t age{0};
        bool active{false};
    };

    static double noteHz(double note) noexcept;
    void tuneVoice(PVoice& v) noexcept;
    void applyVoiceParameters(PVoice& v) noexcept;
    PVoice* allocate() noexcept;

    double sampleRate_{48000.0};
    std::array<PVoice, 24> voices_{};
    std::uint64_t age_{1};

    Waveform waveform_{Waveform::Saw};
    float oscLevel_{0.76f};
    float subLevel_{0.24f};
    float cutoff_{5200.0f};
    float resonance_{0.22f};
    float attack_{0.01f};
    float decay_{0.23f};
    float sustain_{0.72f};
    float release_{0.45f};
    float masterGain_{0.16f};
    float bendSemis_{0.0f};
};

} // namespace kp
