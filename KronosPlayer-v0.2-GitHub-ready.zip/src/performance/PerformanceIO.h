#pragma once
#include "performance/Performance.h"
#include <string>

namespace kp {

bool savePerformance(const Performance& performance,
                     const std::string& path,
                     std::string* error = nullptr);

bool loadPerformance(const std::string& path,
                     Performance& performance,
                     std::string* error = nullptr);

} // namespace kp
