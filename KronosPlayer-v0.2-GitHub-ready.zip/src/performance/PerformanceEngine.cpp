#include "performance/PerformanceEngine.h"
#include <algorithm>
#include <cmath>

namespace kp {

PerformanceEngine::PerformanceEngine()
    : performance_(makeDefaultPerformance()) {
    syncLayerEngines();
}

void PerformanceEngine::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;

    for (auto& r : runtime_) {
        if (r.engine)
            r.engine->setSampleRate(sampleRate_);
    }
}

void PerformanceEngine::syncLayerEngines() {
    for (std::size_t i = 0; i < Performance::kLayerCount; ++i) {
        const auto wanted = performance_.layers[i].engine;

        if (!runtime_[i].engine || runtime_[i].engineType != wanted) {
            runtime_[i].engineType = wanted;
            runtime_[i].engine = createEngine(wanted);
            runtime_[i].engine->setSampleRate(sampleRate_);
        }
    }
}

void PerformanceEngine::setPerformance(const Performance& p) {
    allNotesOff();
    performance_ = p;
    syncLayerEngines();
}

void PerformanceEngine::setLayerEngine(std::size_t layer, EngineType type) {
    if (layer >= Performance::kLayerCount)
        return;

    performance_.layers[layer].engine = type;

    if (!runtime_[layer].engine || runtime_[layer].engineType != type) {
        if (runtime_[layer].engine)
            runtime_[layer].engine->allNotesOff();

        runtime_[layer].engineType = type;
        runtime_[layer].engine = createEngine(type);
        runtime_[layer].engine->setSampleRate(sampleRate_);
    }
}

float PerformanceEngine::clampPan(float p) noexcept {
    return std::clamp(p, -1.0f, 1.0f);
}

std::uint8_t PerformanceEngine::transposeNote(std::uint8_t note, int semis) noexcept {
    int n = static_cast<int>(note) + semis;
    n = std::clamp(n, 0, 127);
    return static_cast<std::uint8_t>(n);
}

bool PerformanceEngine::layerAccepts(const LayerSettings& layer,
                                     const MidiEvent& event) const noexcept {
    if (!layer.enabled)
        return false;

    if (layer.midiChannel >= 0 &&
        static_cast<int>(event.channel) != layer.midiChannel)
        return false;

    if (event.type == MidiType::NoteOn || event.type == MidiType::NoteOff) {
        if (event.data1 < layer.keyLow || event.data1 > layer.keyHigh)
            return false;
    }

    if (event.type == MidiType::NoteOn) {
        if (event.data2 < layer.velocityLow ||
            event.data2 > layer.velocityHigh)
            return false;
    }

    return true;
}

void PerformanceEngine::handleMidi(const MidiEvent& e) noexcept {
    for (std::size_t i = 0; i < Performance::kLayerCount; ++i) {
        auto& layer = performance_.layers[i];
        auto& rt = runtime_[i];

        if (!rt.engine || !layerAccepts(layer, e))
            continue;

        switch (e.type) {
            case MidiType::NoteOn: {
                const auto note = transposeNote(e.data1, layer.transpose);
                rt.engine->noteOn(note, e.data2);
                break;
            }

            case MidiType::NoteOff: {
                const auto note = transposeNote(e.data1, layer.transpose);
                rt.engine->noteOff(note);
                break;
            }

            case MidiType::ControlChange: {
                if (e.data1 == 11) {
                    layer.expression = static_cast<float>(e.data2) / 127.0f;
                }
                rt.engine->controlChange(e.data1, e.data2);
                break;
            }

            case MidiType::PitchBend:
                rt.engine->pitchBend(e.value14);
                break;
        }
    }
}

void PerformanceEngine::render(float* out, std::size_t frames) noexcept {
    if (!out)
        return;

    std::fill(out, out + frames * 2, 0.0f);

    std::size_t done = 0;

    while (done < frames) {
        const std::size_t block =
            std::min(kMaxRenderFrames, frames - done);

        for (std::size_t layerIndex = 0;
             layerIndex < Performance::kLayerCount;
             ++layerIndex) {

            const auto& layer = performance_.layers[layerIndex];
            auto& rt = runtime_[layerIndex];

            if (!layer.enabled || !rt.engine)
                continue;

            std::fill(scratch_.begin(),
                      scratch_.begin() + block * 2,
                      0.0f);

            rt.engine->render(scratch_.data(), block);

            const float pan = clampPan(layer.pan);

            const float left =
                std::sqrt(0.5f * (1.0f - pan)) *
                layer.volume *
                layer.expression;

            const float right =
                std::sqrt(0.5f * (1.0f + pan)) *
                layer.volume *
                layer.expression;

            for (std::size_t i = 0; i < block; ++i) {
                out[(done + i)*2]     += scratch_[i*2]     * left;
                out[(done + i)*2 + 1] += scratch_[i*2 + 1] * right;
            }
        }

        done += block;
    }

    for (std::size_t i = 0; i < frames * 2; ++i)
        out[i] = std::tanh(out[i]);
}

void PerformanceEngine::allNotesOff() noexcept {
    for (auto& r : runtime_) {
        if (r.engine)
            r.engine->allNotesOff();
    }
}

} // namespace kp
