#include "performance/PerformanceIO.h"
#include <algorithm>
#include <fstream>
#include <sstream>

namespace kp {

static std::string engineToString(EngineType t) {
    return engineTypeName(t);
}

static bool engineFromString(const std::string& s, EngineType& out) {
    if (s == "AL-1") {
        out = EngineType::Al1;
        return true;
    }
    if (s == "PolysixEX") {
        out = EngineType::Polysix;
        return true;
    }
    if (s == "CX-3") {
        out = EngineType::Cx3;
        return true;
    }
    return false;
}

bool savePerformance(const Performance& p,
                     const std::string& path,
                     std::string* error) {
    std::ofstream f(path);
    if (!f) {
        if (error) *error = "Cannot open file for writing";
        return false;
    }

    f << "KPERF1\n";
    f << "name=" << p.name << "\n";

    for (std::size_t i = 0; i < Performance::kLayerCount; ++i) {
        const auto& l = p.layers[i];
        const std::string prefix = "layer" + std::to_string(i) + ".";

        f << prefix << "enabled=" << (l.enabled ? 1 : 0) << "\n";
        f << prefix << "engine=" << engineToString(l.engine) << "\n";
        f << prefix << "midiChannel=" << l.midiChannel << "\n";
        f << prefix << "keyLow=" << static_cast<int>(l.keyLow) << "\n";
        f << prefix << "keyHigh=" << static_cast<int>(l.keyHigh) << "\n";
        f << prefix << "velocityLow=" << static_cast<int>(l.velocityLow) << "\n";
        f << prefix << "velocityHigh=" << static_cast<int>(l.velocityHigh) << "\n";
        f << prefix << "transpose=" << l.transpose << "\n";
        f << prefix << "fineTuneCents=" << l.fineTuneCents << "\n";
        f << prefix << "volume=" << l.volume << "\n";
        f << prefix << "pan=" << l.pan << "\n";
        f << prefix << "expression=" << l.expression << "\n";
        f << prefix << "engineParameterCount=" << l.engineParameterCount << "\n";
        for (std::size_t p = 0; p < l.engineParameterCount && p < kMaxEngineParameters; ++p)
            f << prefix << "param" << p << "=" << l.engineParameters[p] << "\n";
    }

    return true;
}

bool loadPerformance(const std::string& path,
                     Performance& p,
                     std::string* error) {
    std::ifstream f(path);
    if (!f) {
        if (error) *error = "Cannot open file";
        return false;
    }

    std::string line;
    if (!std::getline(f, line) || line != "KPERF1") {
        if (error) *error = "Not a KPERF1 file";
        return false;
    }

    Performance temp{};

    while (std::getline(f, line)) {
        const auto eq = line.find('=');
        if (eq == std::string::npos)
            continue;

        const auto key = line.substr(0, eq);
        const auto value = line.substr(eq + 1);

        if (key == "name") {
            temp.name = value;
            continue;
        }

        if (key.rfind("layer", 0) != 0)
            continue;

        const auto dot = key.find('.');
        if (dot == std::string::npos)
            continue;

        const auto indexText = key.substr(5, dot - 5);
        const auto field = key.substr(dot + 1);

        int idx = -1;
        try {
            idx = std::stoi(indexText);
        } catch (...) {
            continue;
        }

        if (idx < 0 || idx >= static_cast<int>(Performance::kLayerCount))
            continue;

        auto& l = temp.layers[static_cast<std::size_t>(idx)];

        try {
            if (field == "enabled") l.enabled = std::stoi(value) != 0;
            else if (field == "engine") {
                EngineType t;
                if (engineFromString(value, t)) l.engine = t;
            }
            else if (field == "midiChannel") l.midiChannel = std::stoi(value);
            else if (field == "keyLow") l.keyLow = static_cast<std::uint8_t>(std::clamp(std::stoi(value), 0, 127));
            else if (field == "keyHigh") l.keyHigh = static_cast<std::uint8_t>(std::clamp(std::stoi(value), 0, 127));
            else if (field == "velocityLow") l.velocityLow = static_cast<std::uint8_t>(std::clamp(std::stoi(value), 1, 127));
            else if (field == "velocityHigh") l.velocityHigh = static_cast<std::uint8_t>(std::clamp(std::stoi(value), 1, 127));
            else if (field == "transpose") l.transpose = std::clamp(std::stoi(value), -48, 48);
            else if (field == "fineTuneCents") l.fineTuneCents = std::stof(value);
            else if (field == "volume") l.volume = std::clamp(std::stof(value), 0.0f, 1.5f);
            else if (field == "pan") l.pan = std::clamp(std::stof(value), -1.0f, 1.0f);
            else if (field == "expression") l.expression = std::clamp(std::stof(value), 0.0f, 1.0f);
            else if (field == "engineParameterCount") l.engineParameterCount = static_cast<std::uint32_t>(std::clamp(std::stoi(value), 0, static_cast<int>(kMaxEngineParameters)));
            else if (field.rfind("param", 0) == 0) {
                const int p = std::stoi(field.substr(5));
                if (p >= 0 && p < static_cast<int>(kMaxEngineParameters))
                    l.engineParameters[static_cast<std::size_t>(p)] = std::stof(value);
            }
        } catch (...) {
            continue;
        }
    }

    p = temp;
    return true;
}

} // namespace kp
