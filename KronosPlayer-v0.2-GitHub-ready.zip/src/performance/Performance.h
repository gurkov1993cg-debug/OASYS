#pragma once
#include "engine/IEngine.h"
#include <array>
#include <cstdint>
#include <string>

namespace kp {

struct LayerSettings {
    bool enabled{false};
    EngineType engine{EngineType::Al1};

    int midiChannel{-1}; // -1 = Omni, otherwise 0..15

    std::uint8_t keyLow{0};
    std::uint8_t keyHigh{127};

    std::uint8_t velocityLow{1};
    std::uint8_t velocityHigh{127};

    int transpose{0};
    float fineTuneCents{0.0f};

    float volume{0.8f};
    float pan{0.0f};

    float expression{1.0f};
};

struct Performance {
    static constexpr std::size_t kLayerCount = 16;

    std::string name{"New Performance"};
    std::array<LayerSettings, kLayerCount> layers{};
};

Performance makeDefaultPerformance();

} // namespace kp
