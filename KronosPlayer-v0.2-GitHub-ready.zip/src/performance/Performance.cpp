#include "performance/Performance.h"

namespace kp {

Performance makeDefaultPerformance() {
    Performance p;
    p.name = "New Performance";

    p.layers[0].enabled = true;
    p.layers[0].engine = EngineType::Al1;
    p.layers[0].volume = 0.85f;

    p.layers[1].enabled = true;
    p.layers[1].engine = EngineType::Polysix;
    p.layers[1].volume = 0.55f;

    p.layers[2].enabled = true;
    p.layers[2].engine = EngineType::Cx3;
    p.layers[2].volume = 0.40f;

    return p;
}

} // namespace kp
