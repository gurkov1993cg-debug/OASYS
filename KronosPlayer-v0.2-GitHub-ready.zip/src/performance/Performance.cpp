#include "performance/Performance.h"
#include "engine/Al1Engine.h"
#include "engine/PolysixEngine.h"
#include "engine/Cx3Engine.h"

namespace kp {

void resetLayerEngineParameters(LayerSettings& l, EngineType type) noexcept {
    l.engine = type;
    l.engineParameters.fill(0.0f);

    if (type == EngineType::Al1) {
        l.engineParameterCount =
            static_cast<std::uint32_t>(Al1Parameter::Count);

        auto set = [&](Al1Parameter p, float v) {
            l.engineParameters[(std::size_t)p] = v;
        };

        set(Al1Parameter::Osc1Wave, 2.0f);
        set(Al1Parameter::Osc1Level, 0.62f);
        set(Al1Parameter::Osc1Semitone, 0.0f);
        set(Al1Parameter::Osc1DetuneCents, 0.0f);

        set(Al1Parameter::Osc2Wave, 3.0f);
        set(Al1Parameter::Osc2Level, 0.38f);
        set(Al1Parameter::Osc2Semitone, -12.0f);
        set(Al1Parameter::Osc2DetuneCents, 7.0f);

        set(Al1Parameter::HardSync, 0.0f);
        set(Al1Parameter::RingMod, 0.0f);
        set(Al1Parameter::SubLevel, 0.0f);
        set(Al1Parameter::NoiseLevel, 0.0f);

        set(Al1Parameter::UnisonVoices, 1.0f);
        set(Al1Parameter::UnisonSpreadCents, 0.0f);
        set(Al1Parameter::PortamentoSeconds, 0.0f);

        set(Al1Parameter::PitchEgAmountSemis, 0.0f);
        set(Al1Parameter::PitchEgAttack, 0.005f);
        set(Al1Parameter::PitchEgDecay, 0.20f);
        set(Al1Parameter::PitchEgRelease, 0.10f);

        set(Al1Parameter::Filter1Mode, 0.0f);
        set(Al1Parameter::Filter1Cutoff, 7000.0f);
        set(Al1Parameter::Filter1Resonance, 0.18f);

        set(Al1Parameter::Filter2Mode, 0.0f);
        set(Al1Parameter::Filter2Cutoff, 12000.0f);
        set(Al1Parameter::Filter2Resonance, 0.05f);

        set(Al1Parameter::FilterRouting, 0.0f);
        set(Al1Parameter::ParallelBalance, 0.5f);
        set(Al1Parameter::FilterKeyTrack, 0.0f);
        set(Al1Parameter::FilterEgAmountOctaves, 0.0f);
        set(Al1Parameter::VelocityToFilterOctaves, 0.0f);
        set(Al1Parameter::AftertouchToFilterOctaves, 0.0f);

        set(Al1Parameter::FilterEgAttack, 0.01f);
        set(Al1Parameter::FilterEgDecay, 0.25f);
        set(Al1Parameter::FilterEgSustain, 0.0f);
        set(Al1Parameter::FilterEgRelease, 0.35f);

        set(Al1Parameter::AmpAttack, 0.008f);
        set(Al1Parameter::AmpDecay, 0.18f);
        set(Al1Parameter::AmpSustain, 0.78f);
        set(Al1Parameter::AmpRelease, 0.30f);

        set(Al1Parameter::LfoWave, 0.0f);
        set(Al1Parameter::LfoRateHz, 5.2f);
        set(Al1Parameter::LfoPitchSemis, 0.0f);
        set(Al1Parameter::LfoFilterOctaves, 0.0f);
        set(Al1Parameter::LfoAmpDepth, 0.0f);
        set(Al1Parameter::ModWheelToLfo, 1.0f);

        set(Al1Parameter::Drive, 1.0f);
        set(Al1Parameter::MasterGain, 0.20f);
    }
    else if (type == EngineType::Polysix) {
        l.engineParameterCount = 10;
        l.engineParameters[(std::size_t)PolysixParameter::Wave] = 2.0f;
        l.engineParameters[(std::size_t)PolysixParameter::OscLevel] = 0.76f;
        l.engineParameters[(std::size_t)PolysixParameter::SubLevel] = 0.24f;
        l.engineParameters[(std::size_t)PolysixParameter::FilterCutoff] = 5200.0f;
        l.engineParameters[(std::size_t)PolysixParameter::FilterResonance] = 0.22f;
        l.engineParameters[(std::size_t)PolysixParameter::AmpAttack] = 0.01f;
        l.engineParameters[(std::size_t)PolysixParameter::AmpDecay] = 0.23f;
        l.engineParameters[(std::size_t)PolysixParameter::AmpSustain] = 0.72f;
        l.engineParameters[(std::size_t)PolysixParameter::AmpRelease] = 0.45f;
        l.engineParameters[(std::size_t)PolysixParameter::MasterGain] = 0.16f;
    }
    else {
        l.engineParameterCount = 10;
        const float d[9] = {
            0.75f, 1.0f, 0.58f, 0.75f, 0.45f,
            0.35f, 0.25f, 0.22f, 0.18f
        };

        for (std::size_t i = 0; i < 9; ++i)
            l.engineParameters[i] = d[i];

        l.engineParameters[(std::size_t)Cx3Parameter::MasterGain] = 0.22f;
    }
}

Performance makeDefaultPerformance() {
    Performance p;
    p.name = "New Performance";

    for (auto& l : p.layers)
        resetLayerEngineParameters(l, EngineType::Al1);

    p.layers[0].enabled = true;
    resetLayerEngineParameters(p.layers[0], EngineType::Al1);
    p.layers[0].volume = 0.85f;

    p.layers[1].enabled = true;
    resetLayerEngineParameters(p.layers[1], EngineType::Polysix);
    p.layers[1].volume = 0.55f;

    p.layers[2].enabled = true;
    resetLayerEngineParameters(p.layers[2], EngineType::Cx3);
    p.layers[2].volume = 0.40f;

    return p;
}

} // namespace kp
