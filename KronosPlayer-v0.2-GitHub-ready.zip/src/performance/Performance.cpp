#include "performance/Performance.h"
#include "engine/Al1Engine.h"
#include "engine/PolysixEngine.h"
#include "engine/Cx3Engine.h"

namespace kp {

void resetLayerEngineParameters(LayerSettings& l, EngineType type) noexcept {
    l.engine = type;
    l.engineParameters.fill(0.0f);

    if (type == EngineType::Al1) {
        l.engineParameterCount = 15;
        l.engineParameters[(std::size_t)Al1Parameter::Osc1Wave] = 2.0f;
        l.engineParameters[(std::size_t)Al1Parameter::Osc1Level] = 0.62f;
        l.engineParameters[(std::size_t)Al1Parameter::Osc1Semitone] = 0.0f;
        l.engineParameters[(std::size_t)Al1Parameter::Osc1DetuneCents] = 0.0f;
        l.engineParameters[(std::size_t)Al1Parameter::Osc2Wave] = 3.0f;
        l.engineParameters[(std::size_t)Al1Parameter::Osc2Level] = 0.38f;
        l.engineParameters[(std::size_t)Al1Parameter::Osc2Semitone] = -12.0f;
        l.engineParameters[(std::size_t)Al1Parameter::Osc2DetuneCents] = 7.0f;
        l.engineParameters[(std::size_t)Al1Parameter::FilterCutoff] = 7000.0f;
        l.engineParameters[(std::size_t)Al1Parameter::FilterResonance] = 0.18f;
        l.engineParameters[(std::size_t)Al1Parameter::AmpAttack] = 0.008f;
        l.engineParameters[(std::size_t)Al1Parameter::AmpDecay] = 0.18f;
        l.engineParameters[(std::size_t)Al1Parameter::AmpSustain] = 0.78f;
        l.engineParameters[(std::size_t)Al1Parameter::AmpRelease] = 0.30f;
        l.engineParameters[(std::size_t)Al1Parameter::MasterGain] = 0.20f;
    }
    else if (type == EngineType::Polysix) {
        l.engineParameterCount = 10;
        l.engineParameters[(std::size_t)PolysixParameter::Wave] = 2.0f;
        l.engineParameters[(std::size_t)PolysixParameter::OscLevel] = 0.76f;
        l.engineParameters[(std::size_t)PolysixParameter::SubLevel] = 0.24f;
        l.engineParameters[(std::size_t)PolysixParameter::FilterCutoff] = 5200.0f;
        l.engineParameters[(std::size_t)PolysixParameter::FilterResonance] = 0.22f;
        l.engineParameters[(std::size_t)PolysixParameter::AmpAttack] = 0.01f;
        l.engineParameters[(std::size_t)PolysixParameter::AmpDecay] = 0.23f;
        l.engineParameters[(std::size_t)PolysixParameter::AmpSustain] = 0.72f;
        l.engineParameters[(std::size_t)PolysixParameter::AmpRelease] = 0.45f;
        l.engineParameters[(std::size_t)PolysixParameter::MasterGain] = 0.16f;
    }
    else {
        l.engineParameterCount = 10;
        const float d[9] = {0.75f, 1.0f, 0.58f, 0.75f, 0.45f, 0.35f, 0.25f, 0.22f, 0.18f};
        for (std::size_t i = 0; i < 9; ++i)
            l.engineParameters[i] = d[i];
        l.engineParameters[(std::size_t)Cx3Parameter::MasterGain] = 0.22f;
    }
}

Performance makeDefaultPerformance() {
    Performance p;
    p.name = "New Performance";

    for (auto& l : p.layers)
        resetLayerEngineParameters(l, EngineType::Al1);

    p.layers[0].enabled = true;
    resetLayerEngineParameters(p.layers[0], EngineType::Al1);
    p.layers[0].volume = 0.85f;

    p.layers[1].enabled = true;
    resetLayerEngineParameters(p.layers[1], EngineType::Polysix);
    p.layers[1].volume = 0.55f;

    p.layers[2].enabled = true;
    resetLayerEngineParameters(p.layers[2], EngineType::Cx3);
    p.layers[2].volume = 0.40f;

    return p;
}

} // namespace kp
