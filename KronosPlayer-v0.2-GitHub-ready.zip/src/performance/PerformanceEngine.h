#pragma once
#include "performance/Performance.h"
#include "engine/EngineFactory.h"
#include "midi/MidiEvent.h"
#include <array>
#include <cstddef>
#include <memory>

namespace kp {

class PerformanceEngine {
public:
    PerformanceEngine();

    void setSampleRate(double sampleRate) noexcept;
    double sampleRate() const noexcept { return sampleRate_; }

    Performance& performance() noexcept { return performance_; }
    const Performance& performance() const noexcept { return performance_; }

    void setPerformance(const Performance& performance);
    void setLayerEngine(std::size_t layer, EngineType type);
    void setEngineParameter(std::size_t layer, std::uint32_t parameterId, float value) noexcept;
    float getEngineParameter(std::size_t layer, std::uint32_t parameterId) const noexcept;

    void handleMidi(const MidiEvent& event) noexcept;
    void render(float* interleavedStereo, std::size_t frames) noexcept;
    void allNotesOff() noexcept;

private:
    struct LayerRuntime {
        EngineType engineType{EngineType::Al1};
        std::unique_ptr<IEngine> engine;
    };

    static float clampPan(float p) noexcept;
    static std::uint8_t transposeNote(std::uint8_t note, int semis) noexcept;

    bool layerAccepts(const LayerSettings& layer,
                      const MidiEvent& event) const noexcept;

    void syncLayerEngines();

    double sampleRate_{48000.0};
    Performance performance_{};
    std::array<LayerRuntime, Performance::kLayerCount> runtime_{};

    static constexpr std::size_t kMaxRenderFrames = 2048;
    std::array<float, kMaxRenderFrames * 2> scratch_{};
};

} // namespace kp
