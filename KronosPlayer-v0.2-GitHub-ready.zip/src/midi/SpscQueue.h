#pragma once
#include <array>
#include <atomic>
#include <cstddef>

namespace kp {

template <typename T, std::size_t Capacity>
class SpscQueue {
public:
    static_assert(Capacity >= 2, "Capacity must be >= 2");

    bool push(const T& item) noexcept {
        const auto h = head_.load(std::memory_order_relaxed);
        const auto next = increment(h);
        if (next == tail_.load(std::memory_order_acquire))
            return false;
        buffer_[h] = item;
        head_.store(next, std::memory_order_release);
        return true;
    }

    bool pop(T& item) noexcept {
        const auto t = tail_.load(std::memory_order_relaxed);
        if (t == head_.load(std::memory_order_acquire))
            return false;
        item = buffer_[t];
        tail_.store(increment(t), std::memory_order_release);
        return true;
    }

private:
    static constexpr std::size_t increment(std::size_t i) noexcept {
        return (i + 1) % Capacity;
    }

    std::array<T, Capacity> buffer_{};
    std::atomic<std::size_t> head_{0};
    std::atomic<std::size_t> tail_{0};
};

} // namespace kp
