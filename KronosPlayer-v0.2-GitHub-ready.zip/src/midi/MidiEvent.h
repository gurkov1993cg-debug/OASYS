#pragma once
#include <cstdint>

namespace kp {

enum class MidiType : std::uint8_t {
    NoteOn,
    NoteOff,
    ControlChange,
    PitchBend,
    ChannelPressure
};

struct MidiEvent {
    MidiType type{MidiType::NoteOn};
    std::uint8_t channel{0}; // 0..15
    std::uint8_t data1{0};
    std::uint8_t data2{0};
    std::uint16_t value14{8192};
};

} // namespace kp
