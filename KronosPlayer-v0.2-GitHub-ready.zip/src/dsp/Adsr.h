#pragma once

namespace kp {

class Adsr {
public:
    void setSampleRate(double sampleRate) noexcept;
    void setParameters(float attackSeconds,
                       float decaySeconds,
                       float sustainLevel,
                       float releaseSeconds) noexcept;

    void noteOn() noexcept;
    void noteOff() noexcept;
    void reset() noexcept;

    float process() noexcept;
    bool isActive() const noexcept;

private:
    enum class Stage { Idle, Attack, Decay, Sustain, Release };

    float coefficient(float seconds) const noexcept;

    double sampleRate_{48000.0};
    float attack_{0.01f};
    float decay_{0.2f};
    float sustain_{0.75f};
    float release_{0.35f};
    float level_{0.0f};
    Stage stage_{Stage::Idle};
};

} // namespace kp
