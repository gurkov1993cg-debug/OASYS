#include "dsp/SvfFilter.h"
#include <algorithm>
#include <cmath>

namespace kp {

static constexpr double kPi = 3.14159265358979323846;

void SvfFilter::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;
    update();
}

void SvfFilter::setCutoff(float hz) noexcept {
    cutoff_ = std::clamp(hz, 20.0f, static_cast<float>(sampleRate_ * 0.45));
    update();
}

void SvfFilter::setResonance(float n) noexcept {
    resonance_ = std::clamp(n, 0.0f, 0.985f);
    update();
}

void SvfFilter::update() noexcept {
    g_ = static_cast<float>(std::tan(kPi * cutoff_ / sampleRate_));
    k_ = 2.0f - 1.97f * resonance_;
}

void SvfFilter::reset() noexcept {
    ic1eq_ = 0.0f;
    ic2eq_ = 0.0f;
}

float SvfFilter::process(float x, FilterMode mode) noexcept {
    const float a1 = 1.0f / (1.0f + g_ * (g_ + k_));
    const float a2 = g_ * a1;
    const float a3 = g_ * a2;

    const float v3 = x - ic2eq_;
    const float band = a1 * ic1eq_ + a2 * v3;
    const float low = ic2eq_ + a2 * ic1eq_ + a3 * v3;
    const float high = x - k_ * band - low;

    ic1eq_ = 2.0f * band - ic1eq_;
    ic2eq_ = 2.0f * low - ic2eq_;

    switch (mode) {
        case FilterMode::LowPass: return low;
        case FilterMode::HighPass: return high;
        case FilterMode::BandPass: return band;
    }
    return low;
}

} // namespace kp
