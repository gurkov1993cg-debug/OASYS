#pragma once
#include <cstdint>

namespace kp {

enum class FilterMode : std::uint8_t {
    LowPass = 0,
    HighPass = 1,
    BandPass = 2
};

class SvfFilter {
public:
    void setSampleRate(double sampleRate) noexcept;
    void setCutoff(float hz) noexcept;
    void setResonance(float normalized) noexcept;
    void reset() noexcept;

    float process(float x, FilterMode mode) noexcept;
    float processLowPass(float x) noexcept { return process(x, FilterMode::LowPass); }

private:
    void update() noexcept;

    double sampleRate_{48000.0};
    float cutoff_{8000.0f};
    float resonance_{0.1f};
    float g_{0.0f};
    float k_{1.8f};
    float ic1eq_{0.0f};
    float ic2eq_{0.0f};
};

} // namespace kp
