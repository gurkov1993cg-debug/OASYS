#pragma once

namespace kp {

class SvfFilter {
public:
    void setSampleRate(double sampleRate) noexcept;
    void setCutoff(float hz) noexcept;
    void setResonance(float normalized) noexcept;
    void reset() noexcept;

    float processLowPass(float x) noexcept;

private:
    void update() noexcept;

    double sampleRate_{48000.0};
    float cutoff_{8000.0f};
    float resonance_{0.1f};
    float g_{0.0f};
    float k_{1.8f};
    float ic1eq_{0.0f};
    float ic2eq_{0.0f};
};

} // namespace kp
