#pragma once
#include <cstdint>

namespace kp {

enum class Waveform : std::uint8_t {
    Sine,
    Triangle,
    Saw,
    Square
};

class Oscillator {
public:
    void setSampleRate(double sampleRate) noexcept;
    void setFrequency(double hz) noexcept;
    void setWaveform(Waveform waveform) noexcept;
    void reset(double phase = 0.0) noexcept;

    float process() noexcept;
    bool didWrap() const noexcept { return wrapped_; }
    double phase() const noexcept { return phase_; }

private:
    static double polyBlep(double t, double dt) noexcept;

    double sampleRate_{48000.0};
    double frequency_{440.0};
    double phase_{0.0};
    double triangleState_{0.0};
    Waveform waveform_{Waveform::Saw};
    bool wrapped_{false};
};

} // namespace kp
