#include "dsp/Adsr.h"
#include <algorithm>
#include <cmath>

namespace kp {

void Adsr::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;
}

void Adsr::setParameters(float a, float d, float s, float r) noexcept {
    attack_ = std::max(a, 0.0001f);
    decay_ = std::max(d, 0.0001f);
    sustain_ = std::clamp(s, 0.0f, 1.0f);
    release_ = std::max(r, 0.0001f);
}

float Adsr::coefficient(float seconds) const noexcept {
    const double samples = std::max(1.0, seconds * sampleRate_);
    return static_cast<float>(1.0 - std::exp(-6.907755278982137 / samples));
}

void Adsr::noteOn() noexcept {
    stage_ = Stage::Attack;
}

void Adsr::noteOff() noexcept {
    if (stage_ != Stage::Idle)
        stage_ = Stage::Release;
}

void Adsr::reset() noexcept {
    level_ = 0.0f;
    stage_ = Stage::Idle;
}

float Adsr::process() noexcept {
    switch (stage_) {
        case Stage::Idle:
            level_ = 0.0f;
            break;

        case Stage::Attack: {
            const float c = coefficient(attack_);
            level_ += (1.0f - level_) * c;
            if (level_ >= 0.999f) {
                level_ = 1.0f;
                stage_ = Stage::Decay;
            }
            break;
        }

        case Stage::Decay: {
            const float c = coefficient(decay_);
            level_ += (sustain_ - level_) * c;
            if (std::abs(level_ - sustain_) < 0.0005f) {
                level_ = sustain_;
                stage_ = Stage::Sustain;
            }
            break;
        }

        case Stage::Sustain:
            level_ = sustain_;
            break;

        case Stage::Release: {
            const float c = coefficient(release_);
            level_ += (0.0f - level_) * c;
            if (level_ <= 0.0001f) {
                level_ = 0.0f;
                stage_ = Stage::Idle;
            }
            break;
        }
    }
    return level_;
}

bool Adsr::isActive() const noexcept {
    return stage_ != Stage::Idle;
}

} // namespace kp
