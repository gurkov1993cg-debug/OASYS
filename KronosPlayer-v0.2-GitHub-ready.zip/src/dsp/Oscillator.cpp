#include "dsp/Oscillator.h"
#include <algorithm>
#include <cmath>

namespace kp {

static constexpr double kTwoPi = 6.2831853071795864769;

void Oscillator::setSampleRate(double sr) noexcept {
    sampleRate_ = sr > 1000.0 ? sr : 48000.0;
}

void Oscillator::setFrequency(double hz) noexcept {
    frequency_ = std::clamp(hz, 0.0, sampleRate_ * 0.45);
}

void Oscillator::setWaveform(Waveform w) noexcept {
    waveform_ = w;
}

void Oscillator::reset(double phase) noexcept {
    phase_ = phase - std::floor(phase);
    triangleState_ = 0.0;
}

double Oscillator::polyBlep(double t, double dt) noexcept {
    if (dt <= 0.0) return 0.0;

    if (t < dt) {
        t /= dt;
        return t + t - t*t - 1.0;
    }

    if (t > 1.0 - dt) {
        t = (t - 1.0) / dt;
        return t*t + t + t + 1.0;
    }

    return 0.0;
}

float Oscillator::process() noexcept {
    const double dt = frequency_ / sampleRate_;
    double y = 0.0;

    switch (waveform_) {
        case Waveform::Sine:
            y = std::sin(kTwoPi * phase_);
            break;

        case Waveform::Saw:
            y = (2.0 * phase_ - 1.0) - polyBlep(phase_, dt);
            break;

        case Waveform::Square: {
            y = phase_ < 0.5 ? 1.0 : -1.0;
            y += polyBlep(phase_, dt);
            double t2 = phase_ + 0.5;
            if (t2 >= 1.0) t2 -= 1.0;
            y -= polyBlep(t2, dt);
            break;
        }

        case Waveform::Triangle: {
            double sq = phase_ < 0.5 ? 1.0 : -1.0;
            sq += polyBlep(phase_, dt);

            double t2 = phase_ + 0.5;
            if (t2 >= 1.0) t2 -= 1.0;
            sq -= polyBlep(t2, dt);

            triangleState_ += (4.0 * frequency_ / sampleRate_) * sq;
            triangleState_ *= 0.9995;
            y = std::clamp(triangleState_, -1.2, 1.2);
            break;
        }
    }

    phase_ += dt;
    phase_ -= std::floor(phase_);
    return static_cast<float>(y);
}

} // namespace kp
