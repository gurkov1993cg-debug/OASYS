#include "performance/PerformanceEngine.h"
#include "performance/PerformanceIO.h"
#include "pcg/PcgReader.h"
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

static void writeLE16(std::ofstream& f, std::uint16_t v) {
    const char b[2] = {
        static_cast<char>(v & 0xff),
        static_cast<char>((v >> 8) & 0xff)
    };
    f.write(b, 2);
}

static void writeLE32(std::ofstream& f, std::uint32_t v) {
    const char b[4] = {
        static_cast<char>(v & 0xff),
        static_cast<char>((v >> 8) & 0xff),
        static_cast<char>((v >> 16) & 0xff),
        static_cast<char>((v >> 24) & 0xff)
    };
    f.write(b, 4);
}

static bool writeWav16(const std::string& path,
                       const std::vector<float>& stereo,
                       int sampleRate) {
    std::ofstream f(path, std::ios::binary);
    if (!f) return false;

    const std::uint16_t channels = 2;
    const std::uint16_t bits = 16;
    const std::uint32_t frames =
        static_cast<std::uint32_t>(stereo.size() / 2);
    const std::uint32_t dataBytes =
        frames * channels * (bits / 8);

    f.write("RIFF", 4);
    writeLE32(f, 36 + dataBytes);
    f.write("WAVE", 4);

    f.write("fmt ", 4);
    writeLE32(f, 16);
    writeLE16(f, 1);
    writeLE16(f, channels);
    writeLE32(f, sampleRate);
    writeLE32(f, sampleRate * channels * (bits / 8));
    writeLE16(f, channels * (bits / 8));
    writeLE16(f, bits);

    f.write("data", 4);
    writeLE32(f, dataBytes);

    for (float x : stereo) {
        x = std::clamp(x, -1.0f, 1.0f);
        const auto s =
            static_cast<std::int16_t>(x * 32767.0f);
        writeLE16(f, static_cast<std::uint16_t>(s));
    }

    return true;
}

int main(int argc, char** argv) {
    if (argc >= 3 && std::string(argv[1]) == "--scan-pcg") {
        kp::PcgReader reader;
        if (!reader.load(argv[2])) {
            std::cerr << "PCG error: " << reader.error() << "\n";
            return 2;
        }

        std::cout << "KORG header: yes\n";
        std::cout << "Model ID: 0x"
                  << std::hex
                  << static_cast<int>(reader.modelId())
                  << std::dec
                  << "\n";

        for (const auto& c : reader.chunks()) {
            std::cout
                << c.fourcc
                << " offset=" << c.offset
                << " size=" << c.size
                << "\n";
        }

        return 0;
    }

    constexpr int sr = 48000;
    constexpr int seconds = 4;

    kp::PerformanceEngine engine;
    engine.setSampleRate(sr);

    kp::Performance performance = kp::makeDefaultPerformance();
    performance.name = "Three Engine Blend";

    performance.layers[0].volume = 0.75f;
    performance.layers[1].volume = 0.50f;
    performance.layers[2].volume = 0.35f;
    performance.layers[2].keyLow = 60;

    engine.setPerformance(performance);

    std::vector<float> audio(sr * seconds * 2, 0.0f);

    kp::MidiEvent on1;
    on1.type = kp::MidiType::NoteOn;
    on1.channel = 0;
    on1.data1 = 60;
    on1.data2 = 110;

    kp::MidiEvent on2 = on1;
    on2.data1 = 67;
    on2.data2 = 100;

    engine.handleMidi(on1);
    engine.handleMidi(on2);

    engine.render(audio.data(), sr * 3);

    kp::MidiEvent off1 = on1;
    off1.type = kp::MidiType::NoteOff;

    kp::MidiEvent off2 = on2;
    off2.type = kp::MidiType::NoteOff;

    engine.handleMidi(off1);
    engine.handleMidi(off2);

    engine.render(audio.data() + sr * 3 * 2, sr);

    const std::string out =
        argc >= 2 ? argv[1] : "kronosplayer-blend.wav";

    if (!writeWav16(out, audio, sr)) {
        std::cerr << "Cannot write WAV\n";
        return 1;
    }

    std::cout << "Rendered 3-engine Performance to: "
              << out << "\n";

    return 0;
}
