#ifdef __APPLE__

#import "platform/macos/OnScreenKeyboard.h"
#include "performance/PerformanceEngine.h"
#include "midi/MidiEvent.h"
#include <algorithm>
#include <array>
#include <cstdint>
#include <vector>

namespace {

struct KeyGeometry {
    NSRect rect{};
    int midiNote{0};
    bool black{false};
};

static bool isBlackNote(int midiNote) {
    switch (midiNote % 12) {
        case 1:
        case 3:
        case 6:
        case 8:
        case 10:
            return true;
        default:
            return false;
    }
}

static NSString* noteName(int midiNote) {
    static NSString* names[12] = {
        @"C", @"C♯", @"D", @"D♯", @"E", @"F",
        @"F♯", @"G", @"G♯", @"A", @"A♯", @"B"
    };

    const int octave = midiNote / 12 - 1;
    return [NSString stringWithFormat:@"%@%d", names[midiNote % 12], octave];
}

}

@implementation KPOnScreenKeyboardView {
    kp::PerformanceEngine* _engine;
    std::vector<KeyGeometry> _keys;
    int _activeMouseNote;
    uint8_t _velocity;
}

- (instancetype)initWithFrame:(NSRect)frame
                       engine:(kp::PerformanceEngine*)engine {
    self = [super initWithFrame:frame];
    if (self) {
        _engine = engine;
        _activeMouseNote = -1;
        _velocity = 110;
        [self setWantsLayer:YES];
    }
    return self;
}

- (BOOL)isFlipped {
    return NO;
}

- (void)setVelocity:(uint8_t)velocity {
    _velocity = (uint8_t)std::clamp<int>((int)velocity, 1, 127);
}

- (void)sendNoteOn:(int)note {
    if (!_engine || note < 0 || note > 127)
        return;

    kp::MidiEvent e{};
    e.type = kp::MidiType::NoteOn;
    e.channel = 0;
    e.data1 = (std::uint8_t)note;
    e.data2 = _velocity;
    _engine->handleMidi(e);
}

- (void)sendNoteOff:(int)note {
    if (!_engine || note < 0 || note > 127)
        return;

    kp::MidiEvent e{};
    e.type = kp::MidiType::NoteOff;
    e.channel = 0;
    e.data1 = (std::uint8_t)note;
    e.data2 = 0;
    _engine->handleMidi(e);
}

- (void)allNotesOff {
    if (_activeMouseNote >= 0) {
        [self sendNoteOff:_activeMouseNote];
        _activeMouseNote = -1;
    }

    if (_engine)
        _engine->allNotesOff();

    [self setNeedsDisplay:YES];
}

- (void)rebuildGeometry {
    _keys.clear();

    // 37 notes: C3 (48) through C6 (84), inclusive.
    static constexpr int firstNote = 48;
    static constexpr int lastNote = 84;

    int whiteCount = 0;
    for (int n = firstNote; n <= lastNote; ++n) {
        if (!isBlackNote(n))
            ++whiteCount;
    }

    const CGFloat width = NSWidth(self.bounds);
    const CGFloat height = NSHeight(self.bounds);
    const CGFloat whiteW = width / (CGFloat)whiteCount;
    const CGFloat blackW = whiteW * 0.62;
    const CGFloat blackH = height * 0.62;

    int whiteIndex = 0;

    for (int n = firstNote; n <= lastNote; ++n) {
        if (isBlackNote(n))
            continue;

        KeyGeometry k;
        k.midiNote = n;
        k.black = false;
        k.rect = NSMakeRect(whiteIndex * whiteW, 0.0, whiteW, height);
        _keys.push_back(k);
        ++whiteIndex;
    }

    whiteIndex = 0;
    for (int n = firstNote; n <= lastNote; ++n) {
        if (!isBlackNote(n)) {
            ++whiteIndex;
            continue;
        }

        KeyGeometry k;
        k.midiNote = n;
        k.black = true;

        const CGFloat centerX = whiteIndex * whiteW;
        k.rect = NSMakeRect(centerX - blackW * 0.5,
                            height - blackH,
                            blackW,
                            blackH);
        _keys.push_back(k);
    }
}

- (int)noteAtPoint:(NSPoint)p {
    // Black keys have visual priority.
    for (auto it = _keys.rbegin(); it != _keys.rend(); ++it) {
        if (it->black && NSPointInRect(p, it->rect))
            return it->midiNote;
    }

    for (const auto& k : _keys) {
        if (!k.black && NSPointInRect(p, k.rect))
            return k.midiNote;
    }

    return -1;
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;

    [super drawRect:dirtyRect];
    [self rebuildGeometry];

    [[NSColor windowBackgroundColor] setFill];
    NSRectFill(self.bounds);

    NSDictionary* textAttrs = @{
        NSFontAttributeName: [NSFont systemFontOfSize:9.0],
        NSForegroundColorAttributeName: [NSColor darkGrayColor]
    };

    for (const auto& k : _keys) {
        if (k.black)
            continue;

        if (k.midiNote == _activeMouseNote)
            [[NSColor selectedControlColor] setFill];
        else
            [[NSColor whiteColor] setFill];

        NSBezierPath* path = [NSBezierPath bezierPathWithRect:k.rect];
        [path fill];

        [[NSColor grayColor] setStroke];
        [path setLineWidth:0.7];
        [path stroke];

        if (k.midiNote % 12 == 0) {
            NSString* label = noteName(k.midiNote);
            NSSize size = [label sizeWithAttributes:textAttrs];
            const CGFloat x = NSMidX(k.rect) - size.width * 0.5;
            const CGFloat y = 5.0;
            [label drawAtPoint:NSMakePoint(x, y) withAttributes:textAttrs];
        }
    }

    for (const auto& k : _keys) {
        if (!k.black)
            continue;

        if (k.midiNote == _activeMouseNote)
            [[NSColor selectedControlColor] setFill];
        else
            [[NSColor blackColor] setFill];

        NSBezierPath* path =
            [NSBezierPath bezierPathWithRoundedRect:k.rect
                                           xRadius:2.0
                                           yRadius:2.0];
        [path fill];

        [[NSColor darkGrayColor] setStroke];
        [path setLineWidth:0.7];
        [path stroke];
    }
}

- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const int note = [self noteAtPoint:p];

    if (note >= 0) {
        if (_activeMouseNote >= 0 && _activeMouseNote != note)
            [self sendNoteOff:_activeMouseNote];

        _activeMouseNote = note;
        [self sendNoteOn:note];
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseDragged:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const int note = [self noteAtPoint:p];

    if (note == _activeMouseNote)
        return;

    if (_activeMouseNote >= 0)
        [self sendNoteOff:_activeMouseNote];

    _activeMouseNote = note;

    if (_activeMouseNote >= 0)
        [self sendNoteOn:_activeMouseNote];

    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;

    if (_activeMouseNote >= 0)
        [self sendNoteOff:_activeMouseNote];

    _activeMouseNote = -1;
    [self setNeedsDisplay:YES];
}

@end

#endif
