#ifdef __APPLE__

#import <Cocoa/Cocoa.h>

#include "performance/PerformanceEngine.h"
#include "midi/SpscQueue.h"
#include "platform/macos/CoreAudioHost.h"
#include "platform/macos/CoreMidiHost.h"
#include "platform/macos/PerformanceEditor.h"

#include <memory>

@interface KPAppDelegate : NSObject <NSApplicationDelegate>
@end

@implementation KPAppDelegate {
    std::unique_ptr<kp::PerformanceEngine> _engine;
    std::unique_ptr<kp::SpscQueue<kp::MidiEvent, 4096>> _queue;
    std::unique_ptr<kp::CoreAudioHost> _audio;
    std::unique_ptr<kp::CoreMidiHost> _midi;

    KPPerformanceEditor* _editor;
    NSWindow* _window;
}

- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;

    _engine = std::make_unique<kp::PerformanceEngine>();
    _queue = std::make_unique<kp::SpscQueue<kp::MidiEvent, 4096>>();

    _audio =
        std::make_unique<kp::CoreAudioHost>(*_engine, *_queue);

    _midi =
        std::make_unique<kp::CoreMidiHost>(*_queue);

    _midi->start();
    _audio->start();

    _editor =
        [[KPPerformanceEditor alloc] initWithEngine:_engine.get()];

    _window = [[NSWindow alloc]
        initWithContentRect:NSMakeRect(0, 0, 1220, 780)
        styleMask:(NSWindowStyleMaskTitled |
                   NSWindowStyleMaskClosable |
                   NSWindowStyleMaskMiniaturizable |
                   NSWindowStyleMaskResizable)
        backing:NSBackingStoreBuffered
        defer:NO];

    [_window setTitle:@"KronosPlayer v0.3"];
    [_window setContentViewController:_editor];
    [_window center];
    [_window makeKeyAndOrderFront:nil];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender {
    (void)sender;
    return YES;
}

- (void)applicationWillTerminate:(NSNotification*)notification {
    (void)notification;

    if (_audio) _audio->stop();
    if (_midi) _midi->stop();
}

@end

int main(int argc, const char* argv[]) {
    (void)argc;
    (void)argv;

    @autoreleasepool {
        NSApplication* app = [NSApplication sharedApplication];
        KPAppDelegate* delegate = [[KPAppDelegate alloc] init];
        [app setDelegate:delegate];
        [app run];
    }

    return 0;
}

#endif
