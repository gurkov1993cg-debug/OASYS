#pragma once
#ifdef __APPLE__

#import <Cocoa/Cocoa.h>

namespace kp {
class PerformanceEngine;
}

@interface KPOnScreenKeyboardView : NSView

- (instancetype)initWithFrame:(NSRect)frame
                       engine:(kp::PerformanceEngine*)engine;

- (void)setVelocity:(uint8_t)velocity;
- (void)allNotesOff;

@end

#endif
