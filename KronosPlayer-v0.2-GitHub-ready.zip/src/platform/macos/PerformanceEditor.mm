#ifdef __APPLE__

#import "platform/macos/PerformanceEditor.h"
#include "performance/PerformanceEngine.h"
#include "performance/PerformanceIO.h"
#include <array>

namespace {

enum ControlField : NSInteger {
    FieldEnabled = 1,
    FieldEngine = 2,
    FieldMidiChannel = 3,
    FieldKeyLow = 4,
    FieldKeyHigh = 5,
    FieldTranspose = 6,
    FieldVolume = 7,
    FieldPan = 8
};

static NSInteger makeTag(NSInteger layer, NSInteger field) {
    return layer * 100 + field;
}

static NSInteger tagLayer(NSInteger tag) {
    return tag / 100;
}

static NSInteger tagField(NSInteger tag) {
    return tag % 100;
}

static NSTextField* label(NSString* text, NSRect frame) {
    NSTextField* t = [[NSTextField alloc] initWithFrame:frame];
    [t setStringValue:text];
    [t setBezeled:NO];
    [t setEditable:NO];
    [t setSelectable:NO];
    [t setDrawsBackground:NO];
    [t setFont:[NSFont systemFontOfSize:11]];
    return t;
}

}

@interface KPPerformanceEditor ()
@end

@implementation KPPerformanceEditor {
    kp::PerformanceEngine* _engine;

    NSScrollView* _scroll;
    NSView* _document;

    NSTextField* _nameField;

    std::array<NSButton*, 16> _enable;
    std::array<NSPopUpButton*, 16> _enginePopup;
    std::array<NSTextField*, 16> _midiChannel;
    std::array<NSTextField*, 16> _keyLow;
    std::array<NSTextField*, 16> _keyHigh;
    std::array<NSTextField*, 16> _transpose;
    std::array<NSSlider*, 16> _volume;
    std::array<NSSlider*, 16> _pan;
}

- (instancetype)initWithEngine:(kp::PerformanceEngine*)engine {
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        _engine = engine;
    }
    return self;
}

- (void)loadView {
    NSView* root = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 1060, 720)];
    self.view = root;

    NSTextField* title =
        label(@"KronosPlayer — 16 Layer Performance", NSMakeRect(20, 680, 500, 25));
    [title setFont:[NSFont boldSystemFontOfSize:18]];
    [root addSubview:title];

    _nameField = [[NSTextField alloc] initWithFrame:NSMakeRect(540, 678, 250, 26)];
    [_nameField setTarget:self];
    [_nameField setAction:@selector(nameChanged:)];
    [root addSubview:_nameField];

    NSButton* save = [[NSButton alloc] initWithFrame:NSMakeRect(805, 676, 100, 30)];
    [save setTitle:@"Save .kperf"];
    [save setTarget:self];
    [save setAction:@selector(savePerformance:)];
    [root addSubview:save];

    NSButton* load = [[NSButton alloc] initWithFrame:NSMakeRect(915, 676, 100, 30)];
    [load setTitle:@"Load .kperf"];
    [load setTarget:self];
    [load setAction:@selector(loadPerformance:)];
    [root addSubview:load];

    _scroll = [[NSScrollView alloc] initWithFrame:NSMakeRect(20, 20, 1020, 645)];
    [_scroll setHasVerticalScroller:YES];
    [_scroll setBorderType:NSBezelBorder];
    [root addSubview:_scroll];

    const CGFloat rowHeight = 42.0;
    const CGFloat docHeight = rowHeight * 16 + 55;

    _document = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 1000, docHeight)];
    [_scroll setDocumentView:_document];

    [_document addSubview:label(@"#", NSMakeRect(10, docHeight - 35, 25, 20))];
    [_document addSubview:label(@"On", NSMakeRect(40, docHeight - 35, 35, 20))];
    [_document addSubview:label(@"Engine", NSMakeRect(90, docHeight - 35, 110, 20))];
    [_document addSubview:label(@"MIDI", NSMakeRect(215, docHeight - 35, 45, 20))];
    [_document addSubview:label(@"Key Low", NSMakeRect(275, docHeight - 35, 55, 20))];
    [_document addSubview:label(@"Key High", NSMakeRect(340, docHeight - 35, 60, 20))];
    [_document addSubview:label(@"Transpose", NSMakeRect(415, docHeight - 35, 65, 20))];
    [_document addSubview:label(@"Volume", NSMakeRect(500, docHeight - 35, 60, 20))];
    [_document addSubview:label(@"Pan", NSMakeRect(745, docHeight - 35, 40, 20))];

    for (NSInteger i = 0; i < 16; ++i) {
        const CGFloat y = docHeight - 78 - i * rowHeight;

        [_document addSubview:
            label([NSString stringWithFormat:@"%ld", (long)(i + 1)],
                  NSMakeRect(10, y + 5, 25, 20))];

        _enable[i] = [[NSButton alloc] initWithFrame:NSMakeRect(42, y, 30, 28)];
        [_enable[i] setButtonType:NSSwitchButton];
        [_enable[i] setTag:makeTag(i, FieldEnabled)];
        [_enable[i] setTarget:self];
        [_enable[i] setAction:@selector(controlChanged:)];
        [_document addSubview:_enable[i]];

        _enginePopup[i] =
            [[NSPopUpButton alloc] initWithFrame:NSMakeRect(85, y, 115, 28)];
        [_enginePopup[i] addItemsWithTitles:@[@"AL-1", @"PolysixEX", @"CX-3"]];
        [_enginePopup[i] setTag:makeTag(i, FieldEngine)];
        [_enginePopup[i] setTarget:self];
        [_enginePopup[i] setAction:@selector(controlChanged:)];
        [_document addSubview:_enginePopup[i]];

        _midiChannel[i] = [[NSTextField alloc] initWithFrame:NSMakeRect(215, y, 45, 25)];
        [_midiChannel[i] setTag:makeTag(i, FieldMidiChannel)];
        [_midiChannel[i] setTarget:self];
        [_midiChannel[i] setAction:@selector(controlChanged:)];
        [_document addSubview:_midiChannel[i]];

        _keyLow[i] = [[NSTextField alloc] initWithFrame:NSMakeRect(275, y, 50, 25)];
        [_keyLow[i] setTag:makeTag(i, FieldKeyLow)];
        [_keyLow[i] setTarget:self];
        [_keyLow[i] setAction:@selector(controlChanged:)];
        [_document addSubview:_keyLow[i]];

        _keyHigh[i] = [[NSTextField alloc] initWithFrame:NSMakeRect(345, y, 50, 25)];
        [_keyHigh[i] setTag:makeTag(i, FieldKeyHigh)];
        [_keyHigh[i] setTarget:self];
        [_keyHigh[i] setAction:@selector(controlChanged:)];
        [_document addSubview:_keyHigh[i]];

        _transpose[i] = [[NSTextField alloc] initWithFrame:NSMakeRect(420, y, 55, 25)];
        [_transpose[i] setTag:makeTag(i, FieldTranspose)];
        [_transpose[i] setTarget:self];
        [_transpose[i] setAction:@selector(controlChanged:)];
        [_document addSubview:_transpose[i]];

        _volume[i] =
            [[NSSlider alloc] initWithFrame:NSMakeRect(500, y, 220, 25)];
        [_volume[i] setMinValue:0.0];
        [_volume[i] setMaxValue:1.5];
        [_volume[i] setContinuous:YES];
        [_volume[i] setTag:makeTag(i, FieldVolume)];
        [_volume[i] setTarget:self];
        [_volume[i] setAction:@selector(controlChanged:)];
        [_document addSubview:_volume[i]];

        _pan[i] =
            [[NSSlider alloc] initWithFrame:NSMakeRect(745, y, 220, 25)];
        [_pan[i] setMinValue:-1.0];
        [_pan[i] setMaxValue:1.0];
        [_pan[i] setContinuous:YES];
        [_pan[i] setTag:makeTag(i, FieldPan)];
        [_pan[i] setTarget:self];
        [_pan[i] setAction:@selector(controlChanged:)];
        [_document addSubview:_pan[i]];
    }

    [self refreshFromEngine];
}

- (void)refreshFromEngine {
    if (!_engine || !_nameField)
        return;

    const auto& p = _engine->performance();

    [_nameField setStringValue:
        [NSString stringWithUTF8String:p.name.c_str()]];

    for (NSInteger i = 0; i < 16; ++i) {
        const auto& l = p.layers[static_cast<std::size_t>(i)];

        [_enable[i] setState:l.enabled ? NSControlStateValueOn : NSControlStateValueOff];
        [_enginePopup[i] selectItemAtIndex:static_cast<NSInteger>(l.engine)];

        [_midiChannel[i] setIntegerValue:
            l.midiChannel < 0 ? 0 : l.midiChannel + 1];

        [_keyLow[i] setIntegerValue:l.keyLow];
        [_keyHigh[i] setIntegerValue:l.keyHigh];
        [_transpose[i] setIntegerValue:l.transpose];

        [_volume[i] setFloatValue:l.volume];
        [_pan[i] setFloatValue:l.pan];
    }
}

- (void)nameChanged:(id)sender {
    (void)sender;
    if (!_engine) return;

    _engine->performance().name =
        [[_nameField stringValue] UTF8String];
}

- (void)controlChanged:(id)sender {
    if (!_engine) return;

    const NSInteger tag = [sender tag];
    const NSInteger layerIndex = tagLayer(tag);
    const NSInteger field = tagField(tag);

    if (layerIndex < 0 || layerIndex >= 16)
        return;

    auto& l =
        _engine->performance().layers[static_cast<std::size_t>(layerIndex)];

    switch (field) {
        case FieldEnabled:
            l.enabled =
                [(NSButton*)sender state] == NSControlStateValueOn;
            break;

        case FieldEngine: {
            const NSInteger idx =
                [(NSPopUpButton*)sender indexOfSelectedItem];

            kp::EngineType type = kp::EngineType::Al1;
            if (idx == 1) type = kp::EngineType::Polysix;
            else if (idx == 2) type = kp::EngineType::Cx3;

            _engine->setLayerEngine(
                static_cast<std::size_t>(layerIndex),
                type);
            break;
        }

        case FieldMidiChannel: {
            NSInteger v = [(NSTextField*)sender integerValue];
            l.midiChannel =
                v <= 0 ? -1 : static_cast<int>(std::clamp<NSInteger>(v - 1, 0, 15));
            break;
        }

        case FieldKeyLow:
            l.keyLow =
                static_cast<std::uint8_t>(
                    std::clamp<NSInteger>(
                        [(NSTextField*)sender integerValue],
                        0,
                        127));
            break;

        case FieldKeyHigh:
            l.keyHigh =
                static_cast<std::uint8_t>(
                    std::clamp<NSInteger>(
                        [(NSTextField*)sender integerValue],
                        0,
                        127));
            break;

        case FieldTranspose:
            l.transpose =
                static_cast<int>(
                    std::clamp<NSInteger>(
                        [(NSTextField*)sender integerValue],
                        -48,
                        48));
            break;

        case FieldVolume:
            l.volume = [(NSSlider*)sender floatValue];
            break;

        case FieldPan:
            l.pan = [(NSSlider*)sender floatValue];
            break;
    }
}

- (void)savePerformance:(id)sender {
    (void)sender;
    if (!_engine) return;

    NSSavePanel* panel = [NSSavePanel savePanel];
    [panel setAllowedFileTypes:@[@"kperf"]];
    [panel setNameFieldStringValue:@"My Performance.kperf"];

    if ([panel runModal] == NSModalResponseOK) {
        std::string error;
        kp::savePerformance(
            _engine->performance(),
            [[[panel URL] path] UTF8String],
            &error);
    }
}

- (void)loadPerformance:(id)sender {
    (void)sender;
    if (!_engine) return;

    NSOpenPanel* panel = [NSOpenPanel openPanel];
    [panel setAllowedFileTypes:@[@"kperf"]];
    [panel setAllowsMultipleSelection:NO];

    if ([panel runModal] == NSModalResponseOK) {
        kp::Performance p;
        std::string error;

        if (kp::loadPerformance(
                [[[panel URL] path] UTF8String],
                p,
                &error)) {
            _engine->setPerformance(p);
            [self refreshFromEngine];
        }
    }
}

@end

#endif
