#ifdef __APPLE__

#import "platform/macos/PerformanceEditor.h"
#include "performance/PerformanceEngine.h"
#include "performance/PerformanceIO.h"
#include "engine/Al1Engine.h"
#include "engine/PolysixEngine.h"
#include "engine/Cx3Engine.h"
#include <algorithm>
#include <array>
#include <cmath>

namespace {

enum ControlField : NSInteger {
    FieldEnabled = 1,
    FieldEngine = 2,
    FieldMidiChannel = 3,
    FieldKeyLow = 4,
    FieldKeyHigh = 5,
    FieldTranspose = 6,
    FieldVolume = 7,
    FieldPan = 8
};

static NSInteger makeTag(NSInteger layer, NSInteger field) {
    return layer * 100 + field;
}

static NSInteger tagLayer(NSInteger tag) {
    return tag / 100;
}

static NSInteger tagField(NSInteger tag) {
    return tag % 100;
}

static NSTextField* makeLabel(NSString* text, NSRect frame, CGFloat size = 11.0) {
    NSTextField* t = [[NSTextField alloc] initWithFrame:frame];
    [t setStringValue:text];
    [t setBezeled:NO];
    [t setEditable:NO];
    [t setSelectable:NO];
    [t setDrawsBackground:NO];
    [t setFont:[NSFont systemFontOfSize:size]];
    return t;
}

static NSSlider* makeSlider(NSRect frame, double min, double max, double value) {
    NSSlider* s = [[NSSlider alloc] initWithFrame:frame];
    [s setMinValue:min];
    [s setMaxValue:max];
    [s setDoubleValue:value];
    [s setContinuous:YES];
    return s;
}

}

@interface KPPerformanceEditor ()
@end

@implementation KPPerformanceEditor {
    kp::PerformanceEngine* _engine;

    NSTextField* _nameField;
    NSPopUpButton* _selectedLayerPopup;
    NSView* _engineEditorView;
    NSTextField* _engineTitle;
    NSInteger _selectedLayer;

    NSScrollView* _layerScroll;
    NSView* _layerDocument;

    std::array<NSButton*, 16> _enable;
    std::array<NSPopUpButton*, 16> _enginePopup;
    std::array<NSTextField*, 16> _midiChannel;
    std::array<NSTextField*, 16> _keyLow;
    std::array<NSTextField*, 16> _keyHigh;
    std::array<NSTextField*, 16> _transpose;
    std::array<NSSlider*, 16> _volume;
    std::array<NSSlider*, 16> _pan;
}

- (instancetype)initWithEngine:(kp::PerformanceEngine*)engine {
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        _engine = engine;
        _selectedLayer = 0;
    }
    return self;
}

- (void)loadView {
    NSView* root = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 1220, 780)];
    self.view = root;

    NSTextField* title = makeLabel(@"KronosPlayer — Performance + Engine Edit", NSMakeRect(18, 742, 500, 28), 18.0);
    [title setFont:[NSFont boldSystemFontOfSize:18]];
    [root addSubview:title];

    [root addSubview:makeLabel(@"Performance", NSMakeRect(520, 746, 90, 18), 11.0)];
    _nameField = [[NSTextField alloc] initWithFrame:NSMakeRect(610, 739, 235, 26)];
    [_nameField setTarget:self];
    [_nameField setAction:@selector(nameChanged:)];
    [root addSubview:_nameField];

    NSButton* save = [[NSButton alloc] initWithFrame:NSMakeRect(855, 737, 105, 30)];
    [save setTitle:@"Save .kperf"];
    [save setTarget:self];
    [save setAction:@selector(savePerformance:)];
    [root addSubview:save];

    NSButton* load = [[NSButton alloc] initWithFrame:NSMakeRect(968, 737, 105, 30)];
    [load setTitle:@"Load .kperf"];
    [load setTarget:self];
    [load setAction:@selector(loadPerformance:)];
    [root addSubview:load];

    NSButton* panic = [[NSButton alloc] initWithFrame:NSMakeRect(1080, 737, 115, 30)];
    [panic setTitle:@"All Notes Off"];
    [panic setTarget:self];
    [panic setAction:@selector(allNotesOff:)];
    [root addSubview:panic];

    // LEFT: 16-part Performance mixer/routing
    _layerScroll = [[NSScrollView alloc] initWithFrame:NSMakeRect(18, 18, 660, 705)];
    [_layerScroll setHasVerticalScroller:YES];
    [_layerScroll setBorderType:NSBezelBorder];
    [root addSubview:_layerScroll];

    const CGFloat rowHeight = 40.0;
    const CGFloat docHeight = rowHeight * 16 + 55.0;
    _layerDocument = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 640, docHeight)];
    [_layerScroll setDocumentView:_layerDocument];

    [_layerDocument addSubview:makeLabel(@"#", NSMakeRect(8, docHeight - 34, 20, 18))];
    [_layerDocument addSubview:makeLabel(@"On", NSMakeRect(35, docHeight - 34, 28, 18))];
    [_layerDocument addSubview:makeLabel(@"Engine", NSMakeRect(72, docHeight - 34, 80, 18))];
    [_layerDocument addSubview:makeLabel(@"MIDI", NSMakeRect(171, docHeight - 34, 38, 18))];
    [_layerDocument addSubview:makeLabel(@"Lo", NSMakeRect(220, docHeight - 34, 25, 18))];
    [_layerDocument addSubview:makeLabel(@"Hi", NSMakeRect(258, docHeight - 34, 25, 18))];
    [_layerDocument addSubview:makeLabel(@"Tr", NSMakeRect(298, docHeight - 34, 25, 18))];
    [_layerDocument addSubview:makeLabel(@"Volume", NSMakeRect(347, docHeight - 34, 50, 18))];
    [_layerDocument addSubview:makeLabel(@"Pan", NSMakeRect(498, docHeight - 34, 40, 18))];

    for (NSInteger i = 0; i < 16; ++i) {
        const CGFloat y = docHeight - 75 - i * rowHeight;

        [_layerDocument addSubview:makeLabel([NSString stringWithFormat:@"%ld", (long)(i + 1)], NSMakeRect(8, y + 5, 22, 18))];

        _enable[i] = [[NSButton alloc] initWithFrame:NSMakeRect(34, y, 28, 26)];
        [_enable[i] setButtonType:NSSwitchButton];
        [_enable[i] setTag:makeTag(i, FieldEnabled)];
        [_enable[i] setTarget:self];
        [_enable[i] setAction:@selector(layerControlChanged:)];
        [_layerDocument addSubview:_enable[i]];

        _enginePopup[i] = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(68, y, 94, 27)];
        [_enginePopup[i] addItemsWithTitles:@[@"AL-1", @"Polysix", @"CX-3"]];
        [_enginePopup[i] setTag:makeTag(i, FieldEngine)];
        [_enginePopup[i] setTarget:self];
        [_enginePopup[i] setAction:@selector(layerControlChanged:)];
        [_layerDocument addSubview:_enginePopup[i]];

        _midiChannel[i] = [[NSTextField alloc] initWithFrame:NSMakeRect(170, y, 38, 24)];
        [_midiChannel[i] setTag:makeTag(i, FieldMidiChannel)];
        [_midiChannel[i] setTarget:self];
        [_midiChannel[i] setAction:@selector(layerControlChanged:)];
        [_layerDocument addSubview:_midiChannel[i]];

        _keyLow[i] = [[NSTextField alloc] initWithFrame:NSMakeRect(216, y, 34, 24)];
        [_keyLow[i] setTag:makeTag(i, FieldKeyLow)];
        [_keyLow[i] setTarget:self];
        [_keyLow[i] setAction:@selector(layerControlChanged:)];
        [_layerDocument addSubview:_keyLow[i]];

        _keyHigh[i] = [[NSTextField alloc] initWithFrame:NSMakeRect(255, y, 34, 24)];
        [_keyHigh[i] setTag:makeTag(i, FieldKeyHigh)];
        [_keyHigh[i] setTarget:self];
        [_keyHigh[i] setAction:@selector(layerControlChanged:)];
        [_layerDocument addSubview:_keyHigh[i]];

        _transpose[i] = [[NSTextField alloc] initWithFrame:NSMakeRect(296, y, 38, 24)];
        [_transpose[i] setTag:makeTag(i, FieldTranspose)];
        [_transpose[i] setTarget:self];
        [_transpose[i] setAction:@selector(layerControlChanged:)];
        [_layerDocument addSubview:_transpose[i]];

        _volume[i] = makeSlider(NSMakeRect(344, y, 140, 24), 0.0, 1.5, 0.8);
        [_volume[i] setTag:makeTag(i, FieldVolume)];
        [_volume[i] setTarget:self];
        [_volume[i] setAction:@selector(layerControlChanged:)];
        [_layerDocument addSubview:_volume[i]];

        _pan[i] = makeSlider(NSMakeRect(494, y, 135, 24), -1.0, 1.0, 0.0);
        [_pan[i] setTag:makeTag(i, FieldPan)];
        [_pan[i] setTarget:self];
        [_pan[i] setAction:@selector(layerControlChanged:)];
        [_layerDocument addSubview:_pan[i]];
    }

    // RIGHT: actual engine parameter editor
    NSBox* editorBox = [[NSBox alloc] initWithFrame:NSMakeRect(695, 18, 507, 705)];
    [editorBox setTitle:@"ENGINE EDIT"];
    [root addSubview:editorBox];

    NSView* boxContent = [editorBox contentView];
    [boxContent addSubview:makeLabel(@"Layer", NSMakeRect(14, 648, 40, 20), 12.0)];

    _selectedLayerPopup = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(58, 642, 90, 28)];
    for (NSInteger i = 1; i <= 16; ++i)
        [_selectedLayerPopup addItemWithTitle:[NSString stringWithFormat:@"Layer %ld", (long)i]];
    [_selectedLayerPopup setTarget:self];
    [_selectedLayerPopup setAction:@selector(selectedLayerChanged:)];
    [boxContent addSubview:_selectedLayerPopup];

    _engineTitle = makeLabel(@"", NSMakeRect(166, 645, 310, 24), 15.0);
    [_engineTitle setFont:[NSFont boldSystemFontOfSize:15]];
    [boxContent addSubview:_engineTitle];

    _engineEditorView = [[NSView alloc] initWithFrame:NSMakeRect(12, 12, 475, 620)];
    [boxContent addSubview:_engineEditorView];

    [self refreshFromEngine];
    [self rebuildEngineEditor];
}

- (void)addEditorLabel:(NSString*)name y:(CGFloat)y {
    [_engineEditorView addSubview:makeLabel(name, NSMakeRect(12, y + 2, 128, 20), 11.0)];
}

- (NSSlider*)addParamSlider:(NSString*)name
                           y:(CGFloat)y
                       param:(std::uint32_t)param
                         min:(double)min
                         max:(double)max {
    [self addEditorLabel:name y:y];
    NSSlider* s = makeSlider(NSMakeRect(144, y, 305, 22), min, max,
                             _engine->getEngineParameter((std::size_t)_selectedLayer, param));
    [s setTag:(NSInteger)(6000 + param)];
    [s setTarget:self];
    [s setAction:@selector(engineSliderChanged:)];
    [_engineEditorView addSubview:s];
    return s;
}

- (NSPopUpButton*)addWavePopup:(NSString*)name
                               y:(CGFloat)y
                           param:(std::uint32_t)param {
    [self addEditorLabel:name y:y];
    NSPopUpButton* p = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(144, y - 2, 170, 27)];
    [p addItemsWithTitles:@[@"Sine", @"Triangle", @"Saw", @"Square"]];
    NSInteger idx = (NSInteger)std::lround(_engine->getEngineParameter((std::size_t)_selectedLayer, param));
    idx = std::clamp<NSInteger>(idx, 0, 3);
    [p selectItemAtIndex:idx];
    [p setTag:(NSInteger)(5000 + param)];
    [p setTarget:self];
    [p setAction:@selector(engineWaveChanged:)];
    [_engineEditorView addSubview:p];
    return p;
}

- (void)rebuildEngineEditor {
    if (!_engine || !_engineEditorView)
        return;

    NSArray* children = [[_engineEditorView subviews] copy];
    for (NSView* v in children)
        [v removeFromSuperview];

    const auto type = _engine->performance().layers[(std::size_t)_selectedLayer].engine;
    [_engineTitle setStringValue:[NSString stringWithFormat:@"%s — real DSP controls", kp::engineTypeName(type)]];

    CGFloat y = 578;

    if (type == kp::EngineType::Al1) {
        [_engineEditorView addSubview:makeLabel(@"OSCILLATOR 1", NSMakeRect(12, y, 180, 22), 13.0)];
        y -= 34;
        [self addWavePopup:@"Waveform" y:y param:(std::uint32_t)kp::Al1Parameter::Osc1Wave];
        y -= 34;
        [self addParamSlider:@"Level" y:y param:(std::uint32_t)kp::Al1Parameter::Osc1Level min:0 max:1];
        y -= 34;
        [self addParamSlider:@"Tune (semitones)" y:y param:(std::uint32_t)kp::Al1Parameter::Osc1Semitone min:-48 max:48];
        y -= 34;
        [self addParamSlider:@"Detune (cents)" y:y param:(std::uint32_t)kp::Al1Parameter::Osc1DetuneCents min:-100 max:100];

        y -= 40;
        [_engineEditorView addSubview:makeLabel(@"OSCILLATOR 2", NSMakeRect(12, y, 180, 22), 13.0)];
        y -= 34;
        [self addWavePopup:@"Waveform" y:y param:(std::uint32_t)kp::Al1Parameter::Osc2Wave];
        y -= 34;
        [self addParamSlider:@"Level" y:y param:(std::uint32_t)kp::Al1Parameter::Osc2Level min:0 max:1];
        y -= 34;
        [self addParamSlider:@"Tune (semitones)" y:y param:(std::uint32_t)kp::Al1Parameter::Osc2Semitone min:-48 max:48];
        y -= 34;
        [self addParamSlider:@"Detune (cents)" y:y param:(std::uint32_t)kp::Al1Parameter::Osc2DetuneCents min:-100 max:100];

        y -= 40;
        [_engineEditorView addSubview:makeLabel(@"FILTER", NSMakeRect(12, y, 180, 22), 13.0)];
        y -= 34;
        [self addParamSlider:@"Cutoff (Hz)" y:y param:(std::uint32_t)kp::Al1Parameter::FilterCutoff min:20 max:18000];
        y -= 34;
        [self addParamSlider:@"Resonance" y:y param:(std::uint32_t)kp::Al1Parameter::FilterResonance min:0 max:0.98];

        y -= 40;
        [_engineEditorView addSubview:makeLabel(@"AMP EG", NSMakeRect(12, y, 180, 22), 13.0)];
        y -= 34;
        [self addParamSlider:@"Attack" y:y param:(std::uint32_t)kp::Al1Parameter::AmpAttack min:0.001 max:5.0];
        y -= 34;
        [self addParamSlider:@"Decay" y:y param:(std::uint32_t)kp::Al1Parameter::AmpDecay min:0.001 max:5.0];
        y -= 34;
        [self addParamSlider:@"Sustain" y:y param:(std::uint32_t)kp::Al1Parameter::AmpSustain min:0 max:1];
        y -= 34;
        [self addParamSlider:@"Release" y:y param:(std::uint32_t)kp::Al1Parameter::AmpRelease min:0.001 max:8.0];
        y -= 34;
        [self addParamSlider:@"Output Gain" y:y param:(std::uint32_t)kp::Al1Parameter::MasterGain min:0 max:1];
    }
    else if (type == kp::EngineType::Polysix) {
        [_engineEditorView addSubview:makeLabel(@"POLYSIXEX SYNTH", NSMakeRect(12, y, 200, 22), 13.0)];
        y -= 38;
        [self addWavePopup:@"Osc Wave" y:y param:(std::uint32_t)kp::PolysixParameter::Wave];
        y -= 36;
        [self addParamSlider:@"Osc Level" y:y param:(std::uint32_t)kp::PolysixParameter::OscLevel min:0 max:1];
        y -= 36;
        [self addParamSlider:@"Sub Level" y:y param:(std::uint32_t)kp::PolysixParameter::SubLevel min:0 max:1];
        y -= 36;
        [self addParamSlider:@"Filter Cutoff" y:y param:(std::uint32_t)kp::PolysixParameter::FilterCutoff min:20 max:18000];
        y -= 36;
        [self addParamSlider:@"Resonance" y:y param:(std::uint32_t)kp::PolysixParameter::FilterResonance min:0 max:0.98];
        y -= 36;
        [self addParamSlider:@"Attack" y:y param:(std::uint32_t)kp::PolysixParameter::AmpAttack min:0.001 max:5.0];
        y -= 36;
        [self addParamSlider:@"Decay" y:y param:(std::uint32_t)kp::PolysixParameter::AmpDecay min:0.001 max:5.0];
        y -= 36;
        [self addParamSlider:@"Sustain" y:y param:(std::uint32_t)kp::PolysixParameter::AmpSustain min:0 max:1];
        y -= 36;
        [self addParamSlider:@"Release" y:y param:(std::uint32_t)kp::PolysixParameter::AmpRelease min:0.001 max:8.0];
        y -= 36;
        [self addParamSlider:@"Output Gain" y:y param:(std::uint32_t)kp::PolysixParameter::MasterGain min:0 max:1];
    }
    else {
        [_engineEditorView addSubview:makeLabel(@"CX-3 DRAWBARS", NSMakeRect(12, y, 200, 22), 13.0)];
        static NSString* names[9] = {@"16'", @"5 1/3'", @"8'", @"4'", @"2 2/3'", @"2'", @"1 3/5'", @"1 1/3'", @"1'"};
        for (std::uint32_t i = 0; i < 9; ++i) {
            y -= 42;
            [self addParamSlider:names[i] y:y param:i min:0 max:1];
        }
        y -= 42;
        [self addParamSlider:@"Output Gain" y:y param:(std::uint32_t)kp::Cx3Parameter::MasterGain min:0 max:1];
    }
}

- (void)refreshFromEngine {
    if (!_engine || !_nameField)
        return;

    const auto& p = _engine->performance();
    [_nameField setStringValue:[NSString stringWithUTF8String:p.name.c_str()]];

    for (NSInteger i = 0; i < 16; ++i) {
        const auto& l = p.layers[(std::size_t)i];
        [_enable[i] setState:l.enabled ? NSControlStateValueOn : NSControlStateValueOff];
        [_enginePopup[i] selectItemAtIndex:(NSInteger)l.engine];
        [_midiChannel[i] setIntegerValue:l.midiChannel < 0 ? 0 : l.midiChannel + 1];
        [_keyLow[i] setIntegerValue:l.keyLow];
        [_keyHigh[i] setIntegerValue:l.keyHigh];
        [_transpose[i] setIntegerValue:l.transpose];
        [_volume[i] setFloatValue:l.volume];
        [_pan[i] setFloatValue:l.pan];
    }
}

- (void)selectedLayerChanged:(id)sender {
    _selectedLayer = [(NSPopUpButton*)sender indexOfSelectedItem];
    _selectedLayer = std::clamp<NSInteger>(_selectedLayer, 0, 15);
    [self rebuildEngineEditor];
}

- (void)engineWaveChanged:(id)sender {
    const NSInteger tag = [sender tag];
    const std::uint32_t param = (std::uint32_t)(tag - 5000);
    const float value = (float)[(NSPopUpButton*)sender indexOfSelectedItem];
    _engine->setEngineParameter((std::size_t)_selectedLayer, param, value);
}

- (void)engineSliderChanged:(id)sender {
    const NSInteger tag = [sender tag];
    const std::uint32_t param = (std::uint32_t)(tag - 6000);
    const float value = [(NSSlider*)sender floatValue];
    _engine->setEngineParameter((std::size_t)_selectedLayer, param, value);
}

- (void)nameChanged:(id)sender {
    (void)sender;
    if (_engine)
        _engine->performance().name = [[_nameField stringValue] UTF8String];
}

- (void)layerControlChanged:(id)sender {
    if (!_engine) return;

    const NSInteger tag = [sender tag];
    const NSInteger layerIndex = tagLayer(tag);
    const NSInteger field = tagField(tag);
    if (layerIndex < 0 || layerIndex >= 16)
        return;

    auto& l = _engine->performance().layers[(std::size_t)layerIndex];

    switch (field) {
        case FieldEnabled:
            l.enabled = [(NSButton*)sender state] == NSControlStateValueOn;
            break;
        case FieldEngine: {
            const NSInteger idx = [(NSPopUpButton*)sender indexOfSelectedItem];
            kp::EngineType type = kp::EngineType::Al1;
            if (idx == 1) type = kp::EngineType::Polysix;
            else if (idx == 2) type = kp::EngineType::Cx3;
            _engine->setLayerEngine((std::size_t)layerIndex, type);
            if (layerIndex == _selectedLayer)
                [self rebuildEngineEditor];
            break;
        }
        case FieldMidiChannel: {
            NSInteger v = [(NSTextField*)sender integerValue];
            l.midiChannel = v <= 0 ? -1 : (int)std::clamp<NSInteger>(v - 1, 0, 15);
            break;
        }
        case FieldKeyLow:
            l.keyLow = (std::uint8_t)std::clamp<NSInteger>([(NSTextField*)sender integerValue], 0, 127);
            break;
        case FieldKeyHigh:
            l.keyHigh = (std::uint8_t)std::clamp<NSInteger>([(NSTextField*)sender integerValue], 0, 127);
            break;
        case FieldTranspose:
            l.transpose = (int)std::clamp<NSInteger>([(NSTextField*)sender integerValue], -48, 48);
            break;
        case FieldVolume:
            l.volume = [(NSSlider*)sender floatValue];
            break;
        case FieldPan:
            l.pan = [(NSSlider*)sender floatValue];
            break;
    }
}

- (void)allNotesOff:(id)sender {
    (void)sender;
    if (_engine) _engine->allNotesOff();
}

- (void)savePerformance:(id)sender {
    (void)sender;
    if (!_engine) return;

    NSSavePanel* panel = [NSSavePanel savePanel];
    [panel setAllowedFileTypes:@[@"kperf"]];
    [panel setNameFieldStringValue:@"My Performance.kperf"];

    if ([panel runModal] == NSModalResponseOK) {
        std::string error;
        kp::savePerformance(_engine->performance(), [[[panel URL] path] UTF8String], &error);
    }
}

- (void)loadPerformance:(id)sender {
    (void)sender;
    if (!_engine) return;

    NSOpenPanel* panel = [NSOpenPanel openPanel];
    [panel setAllowedFileTypes:@[@"kperf"]];
    [panel setAllowsMultipleSelection:NO];

    if ([panel runModal] == NSModalResponseOK) {
        kp::Performance p;
        std::string error;
        if (kp::loadPerformance([[[panel URL] path] UTF8String], p, &error)) {
            _engine->setPerformance(p);
            [self refreshFromEngine];
            [self rebuildEngineEditor];
        }
    }
}

@end

#endif
