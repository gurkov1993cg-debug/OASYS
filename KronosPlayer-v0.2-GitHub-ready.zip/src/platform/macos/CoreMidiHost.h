#pragma once
#ifdef __APPLE__

#include "midi/MidiEvent.h"
#include "midi/SpscQueue.h"
#include <CoreMIDI/CoreMIDI.h>

namespace kp {

class CoreMidiHost {
public:
    explicit CoreMidiHost(SpscQueue<MidiEvent, 4096>& queue);
    ~CoreMidiHost();

    bool start();
    void stop();

private:
    static void midiRead(
        const MIDIPacketList* packets,
        void* readProcRefCon,
        void* srcConnRefCon);

    void handleBytes(const Byte* data, UInt16 length) noexcept;
    void dispatchMessage(std::uint8_t status,
                         std::uint8_t d1,
                         std::uint8_t d2,
                         int dataCount) noexcept;

    SpscQueue<MidiEvent, 4096>& queue_;
    MIDIClientRef client_{0};
    MIDIPortRef inputPort_{0};

    std::uint8_t runningStatus_{0};
    std::uint8_t pendingData_[2]{0, 0};
    int pendingCount_{0};
    int expectedData_{0};
};

} // namespace kp
#endif
