#pragma once
#ifdef __APPLE__

#import <Cocoa/Cocoa.h>

namespace kp {
class PerformanceEngine;
}

@interface KPPerformanceEditor : NSViewController

- (instancetype)initWithEngine:(kp::PerformanceEngine*)engine;
- (void)refreshFromEngine;

@end

#endif
