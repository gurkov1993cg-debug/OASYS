#ifdef __APPLE__
#include "platform/macos/CoreAudioHost.h"
#include <AudioToolbox/AudioToolbox.h>
#include <cstring>

namespace kp {

CoreAudioHost::CoreAudioHost(
    PerformanceEngine& engine,
    SpscQueue<MidiEvent, 4096>& queue)
    : engine_(engine), midiQueue_(queue) {}

CoreAudioHost::~CoreAudioHost() {
    stop();
}

bool CoreAudioHost::start() {
    AudioComponentDescription desc{};
    desc.componentType = kAudioUnitType_Output;
    desc.componentSubType = kAudioUnitSubType_DefaultOutput;
    desc.componentManufacturer = kAudioUnitManufacturer_Apple;

    AudioComponent comp =
        AudioComponentFindNext(nullptr, &desc);

    if (!comp)
        return false;

    if (AudioComponentInstanceNew(comp, &unit_) != noErr)
        return false;

    AudioStreamBasicDescription fmt{};
    fmt.mSampleRate = 48000.0;
    fmt.mFormatID = kAudioFormatLinearPCM;
    fmt.mFormatFlags =
        kAudioFormatFlagIsFloat |
        kAudioFormatFlagIsPacked;
    fmt.mBytesPerPacket = sizeof(float) * 2;
    fmt.mFramesPerPacket = 1;
    fmt.mBytesPerFrame = sizeof(float) * 2;
    fmt.mChannelsPerFrame = 2;
    fmt.mBitsPerChannel = 32;

    if (AudioUnitSetProperty(
            unit_,
            kAudioUnitProperty_StreamFormat,
            kAudioUnitScope_Input,
            0,
            &fmt,
            sizeof(fmt)) != noErr) {
        stop();
        return false;
    }

    AURenderCallbackStruct cb{};
    cb.inputProc = &CoreAudioHost::renderCallback;
    cb.inputProcRefCon = this;

    if (AudioUnitSetProperty(
            unit_,
            kAudioUnitProperty_SetRenderCallback,
            kAudioUnitScope_Input,
            0,
            &cb,
            sizeof(cb)) != noErr) {
        stop();
        return false;
    }

    engine_.setSampleRate(fmt.mSampleRate);

    if (AudioUnitInitialize(unit_) != noErr) {
        stop();
        return false;
    }

    return AudioOutputUnitStart(unit_) == noErr;
}

void CoreAudioHost::stop() {
    if (unit_) {
        AudioOutputUnitStop(unit_);
        AudioUnitUninitialize(unit_);
        AudioComponentInstanceDispose(unit_);
        unit_ = nullptr;
    }
}

OSStatus CoreAudioHost::renderCallback(
    void* refCon,
    AudioUnitRenderActionFlags*,
    const AudioTimeStamp*,
    UInt32,
    UInt32 frames,
    AudioBufferList* ioData) {

    auto* self = static_cast<CoreAudioHost*>(refCon);
    if (!self || !ioData)
        return noErr;

    MidiEvent e;
    while (self->midiQueue_.pop(e))
        self->engine_.handleMidi(e);

    if (ioData->mNumberBuffers == 1 &&
        ioData->mBuffers[0].mData &&
        ioData->mBuffers[0].mNumberChannels == 2) {

        self->engine_.render(
            static_cast<float*>(ioData->mBuffers[0].mData),
            frames);

        return noErr;
    }

    for (UInt32 b = 0; b < ioData->mNumberBuffers; ++b) {
        if (ioData->mBuffers[b].mData) {
            std::memset(
                ioData->mBuffers[b].mData,
                0,
                ioData->mBuffers[b].mDataByteSize);
        }
    }

    return noErr;
}

} // namespace kp
#endif
