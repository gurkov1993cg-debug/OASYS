#pragma once
#ifdef __APPLE__

#include "performance/PerformanceEngine.h"
#include "midi/MidiEvent.h"
#include "midi/SpscQueue.h"
#include <AudioUnit/AudioUnit.h>

namespace kp {

class CoreAudioHost {
public:
    CoreAudioHost(PerformanceEngine& engine,
                  SpscQueue<MidiEvent, 4096>& midiQueue);
    ~CoreAudioHost();

    bool start();
    void stop();

private:
    static OSStatus renderCallback(
        void* refCon,
        AudioUnitRenderActionFlags* flags,
        const AudioTimeStamp* timeStamp,
        UInt32 busNumber,
        UInt32 frames,
        AudioBufferList* ioData);

    PerformanceEngine& engine_;
    SpscQueue<MidiEvent, 4096>& midiQueue_;
    AudioComponentInstance unit_{nullptr};
};

} // namespace kp
#endif
