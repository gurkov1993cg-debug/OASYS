#ifdef __APPLE__
#include "platform/macos/CoreMidiHost.h"

namespace kp {

CoreMidiHost::CoreMidiHost(
    SpscQueue<MidiEvent, 4096>& queue)
    : queue_(queue) {}

CoreMidiHost::~CoreMidiHost() {
    stop();
}

bool CoreMidiHost::start() {
    if (MIDIClientCreate(
            CFSTR("KronosPlayer MIDI"),
            nullptr,
            nullptr,
            &client_) != noErr) {
        return false;
    }

    if (MIDIInputPortCreate(
            client_,
            CFSTR("KronosPlayer Input"),
            &CoreMidiHost::midiRead,
            this,
            &inputPort_) != noErr) {
        stop();
        return false;
    }

    const ItemCount count = MIDIGetNumberOfSources();
    for (ItemCount i = 0; i < count; ++i) {
        MIDIEndpointRef src = MIDIGetSource(i);
        if (src)
            MIDIPortConnectSource(inputPort_, src, nullptr);
    }

    return true;
}

void CoreMidiHost::stop() {
    if (inputPort_) {
        MIDIPortDispose(inputPort_);
        inputPort_ = 0;
    }

    if (client_) {
        MIDIClientDispose(client_);
        client_ = 0;
    }

    runningStatus_ = 0;
    pendingCount_ = 0;
    expectedData_ = 0;
}

void CoreMidiHost::midiRead(
    const MIDIPacketList* packets,
    void* readProcRefCon,
    void*) {

    auto* self =
        static_cast<CoreMidiHost*>(readProcRefCon);

    if (!self || !packets)
        return;

    const MIDIPacket* packet = &packets->packet[0];

    for (UInt32 p = 0; p < packets->numPackets; ++p) {
        self->handleBytes(packet->data, packet->length);
        packet = MIDIPacketNext(packet);
    }
}

void CoreMidiHost::dispatchMessage(std::uint8_t status,
                                   std::uint8_t d1,
                                   std::uint8_t d2,
                                   int dataCount) noexcept {
    const std::uint8_t type = status & 0xF0;
    const std::uint8_t channel = status & 0x0F;

    MidiEvent e{};
    e.channel = channel;
    e.data1 = d1 & 0x7F;
    e.data2 = d2 & 0x7F;

    if (type == 0x80 && dataCount == 2) {
        e.type = MidiType::NoteOff;
    }
    else if (type == 0x90 && dataCount == 2) {
        e.type = (e.data2 == 0) ? MidiType::NoteOff : MidiType::NoteOn;
    }
    else if (type == 0xB0 && dataCount == 2) {
        e.type = MidiType::ControlChange;
    }
    else if (type == 0xD0 && dataCount == 1) {
        e.type = MidiType::ChannelPressure;
    }
    else if (type == 0xE0 && dataCount == 2) {
        e.type = MidiType::PitchBend;
        e.value14 =
            static_cast<std::uint16_t>(
                e.data1 |
                (static_cast<std::uint16_t>(e.data2) << 7));
    }
    else {
        return;
    }

    queue_.push(e);
}

void CoreMidiHost::handleBytes(
    const Byte* data,
    UInt16 length) noexcept {

    for (UInt16 i = 0; i < length; ++i) {
        const std::uint8_t b = data[i];

        if (b >= 0xF8) {
            // MIDI real-time byte: ignore without disturbing running status.
            continue;
        }

        if (b & 0x80) {
            if (b >= 0xF0) {
                runningStatus_ = 0;
                pendingCount_ = 0;
                expectedData_ = 0;
                continue;
            }

            runningStatus_ = b;
            pendingCount_ = 0;

            const std::uint8_t type = runningStatus_ & 0xF0;
            expectedData_ =
                (type == 0xC0 || type == 0xD0) ? 1 : 2;
            continue;
        }

        if (!runningStatus_ || expectedData_ <= 0)
            continue;

        if (pendingCount_ < 2)
            pendingData_[pendingCount_++] = b & 0x7F;

        if (pendingCount_ >= expectedData_) {
            const std::uint8_t d1 = pendingData_[0];
            const std::uint8_t d2 =
                expectedData_ > 1 ? pendingData_[1] : 0;

            dispatchMessage(runningStatus_, d1, d2, expectedData_);
            pendingCount_ = 0;
        }
    }
}

} // namespace kp
#endif
