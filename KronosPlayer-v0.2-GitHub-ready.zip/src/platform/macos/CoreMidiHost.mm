#ifdef __APPLE__
#include "platform/macos/CoreMidiHost.h"

namespace kp {

CoreMidiHost::CoreMidiHost(
    SpscQueue<MidiEvent, 4096>& queue)
    : queue_(queue) {}

CoreMidiHost::~CoreMidiHost() {
    stop();
}

bool CoreMidiHost::start() {
    if (MIDIClientCreate(
            CFSTR("KronosPlayer MIDI"),
            nullptr,
            nullptr,
            &client_) != noErr) {
        return false;
    }

    if (MIDIInputPortCreate(
            client_,
            CFSTR("KronosPlayer Input"),
            &CoreMidiHost::midiRead,
            this,
            &inputPort_) != noErr) {
        stop();
        return false;
    }

    const ItemCount count = MIDIGetNumberOfSources();

    for (ItemCount i = 0; i < count; ++i) {
        MIDIEndpointRef src = MIDIGetSource(i);
        if (src)
            MIDIPortConnectSource(inputPort_, src, nullptr);
    }

    return true;
}

void CoreMidiHost::stop() {
    if (inputPort_) {
        MIDIPortDispose(inputPort_);
        inputPort_ = 0;
    }

    if (client_) {
        MIDIClientDispose(client_);
        client_ = 0;
    }
}

void CoreMidiHost::midiRead(
    const MIDIPacketList* packets,
    void* readProcRefCon,
    void*) {

    auto* self =
        static_cast<CoreMidiHost*>(readProcRefCon);

    if (!self || !packets)
        return;

    const MIDIPacket* packet = &packets->packet[0];

    for (UInt32 p = 0; p < packets->numPackets; ++p) {
        self->handleBytes(packet->data, packet->length);
        packet = MIDIPacketNext(packet);
    }
}

void CoreMidiHost::handleBytes(
    const Byte* data,
    UInt16 length) noexcept {

    UInt16 i = 0;

    while (i < length) {
        const Byte status = data[i];

        if ((status & 0x80) == 0) {
            ++i;
            continue;
        }

        const Byte type = status & 0xF0;
        const Byte channel = status & 0x0F;

        if ((type == 0x80 ||
             type == 0x90 ||
             type == 0xB0 ||
             type == 0xE0) &&
            i + 2 < length) {

            MidiEvent e{};
            e.channel = channel;
            e.data1 = data[i + 1] & 0x7F;
            e.data2 = data[i + 2] & 0x7F;

            if (type == 0x80 ||
                (type == 0x90 && e.data2 == 0)) {
                e.type = MidiType::NoteOff;
            } else if (type == 0x90) {
                e.type = MidiType::NoteOn;
            } else if (type == 0xB0) {
                e.type = MidiType::ControlChange;
            } else {
                e.type = MidiType::PitchBend;
                e.value14 =
                    static_cast<std::uint16_t>(
                        e.data1 |
                        (static_cast<std::uint16_t>(e.data2) << 7));
            }

            queue_.push(e);
            i += 3;
        } else {
            ++i;
        }
    }
}

} // namespace kp
#endif
