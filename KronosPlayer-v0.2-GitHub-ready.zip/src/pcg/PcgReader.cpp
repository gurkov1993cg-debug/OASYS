#include "pcg/PcgReader.h"
#include <fstream>
#include <iterator>
#include <vector>

namespace kp {

std::uint32_t PcgReader::readBe32(const unsigned char* p) noexcept {
    return (static_cast<std::uint32_t>(p[0]) << 24)
         | (static_cast<std::uint32_t>(p[1]) << 16)
         | (static_cast<std::uint32_t>(p[2]) << 8)
         |  static_cast<std::uint32_t>(p[3]);
}

bool PcgReader::looksLikeFourCC(const unsigned char* p) noexcept {
    for (int i = 0; i < 4; ++i) {
        if (p[i] < 0x20 || p[i] > 0x7e)
            return false;
    }
    return true;
}

bool PcgReader::load(const std::string& path) {
    validKorg_ = false;
    modelId_ = 0;
    chunks_.clear();
    error_.clear();

    std::ifstream f(path, std::ios::binary);
    if (!f) {
        error_ = "Cannot open file";
        return false;
    }

    std::vector<unsigned char> data(
        (std::istreambuf_iterator<char>(f)),
        std::istreambuf_iterator<char>());

    if (data.size() < 32) {
        error_ = "File too small";
        return false;
    }

    if (!(data[0] == 'K' &&
          data[1] == 'O' &&
          data[2] == 'R' &&
          data[3] == 'G')) {
        error_ = "Missing KORG header";
        return false;
    }

    validKorg_ = true;
    modelId_ = data[4];

    for (std::size_t i = 0; i + 8 <= data.size(); ++i) {
        if (!looksLikeFourCC(&data[i]))
            continue;

        const auto size = readBe32(&data[i + 4]);

        if (size > data.size())
            continue;

        if (i + 8ull + size > data.size())
            continue;

        PcgChunk c;
        c.fourcc.assign(reinterpret_cast<const char*>(&data[i]), 4);
        c.offset = static_cast<std::uint32_t>(i);
        c.size = size;
        chunks_.push_back(c);

        if (size > 0)
            i += 7;
    }

    return true;
}

} // namespace kp
