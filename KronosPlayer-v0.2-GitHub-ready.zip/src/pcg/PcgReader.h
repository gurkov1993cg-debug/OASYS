#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace kp {

struct PcgChunk {
    std::string fourcc;
    std::uint32_t offset{0};
    std::uint32_t size{0};
};

class PcgReader {
public:
    bool load(const std::string& path);

    bool isKorgPcg() const noexcept { return validKorg_; }
    std::uint8_t modelId() const noexcept { return modelId_; }
    const std::vector<PcgChunk>& chunks() const noexcept { return chunks_; }
    const std::string& error() const noexcept { return error_; }

private:
    static std::uint32_t readBe32(const unsigned char* p) noexcept;
    static bool looksLikeFourCC(const unsigned char* p) noexcept;

    bool validKorg_{false};
    std::uint8_t modelId_{0};
    std::vector<PcgChunk> chunks_;
    std::string error_;
};

} // namespace kp
