# KronosPlayer architecture

```text
CoreMIDI
   |
   v
SPSC MIDI queue
   |
   v
PerformanceEngine (16 layers)
   |
   +-- Layer 1 -> AL-1 Core
   +-- Layer 2 -> PolysixEX Core
   +-- Layer 3 -> CX-3 Core
   +-- ...
   |
   v
Stereo mixer
   |
   v
CoreAudio
```

The DSP and performance layer are plain C++17.

Objective-C++ is used only for:
- CoreAudio host
- CoreMIDI host
- Cocoa editor

## Real-time rules

- fixed voice pools
- fixed layer count
- fixed MIDI queue capacity
- no mutex in audio callback
- no heap allocation in normal engine rendering
- CoreMIDI -> SPSC queue -> CoreAudio
