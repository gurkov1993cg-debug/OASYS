# KronosPlayer v0.3 architecture

```text
CoreMIDI
   |
   v
SPSC MIDI queue
   |
   v
PerformanceEngine (16 layers)
   |
   +-- Layer -> AL-1 Core
   +-- Layer -> PolysixEX Core
   +-- Layer -> CX-3 Core
   |
   v
Stereo mixer
   |
   v
CoreAudio
```

The native Cocoa editor has a 16-part performance view plus an engine editor. Engine controls call real DSP parameter setters. `.kperf` stores both performance routing and the engine parameter state for each layer.

The DSP and performance system are plain C++17. Objective-C++ is used only for CoreAudio, CoreMIDI and Cocoa.
